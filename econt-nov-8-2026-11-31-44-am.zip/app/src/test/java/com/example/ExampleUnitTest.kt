package com.example

import com.example.data.model.CountdownEntity
import com.example.ui.components.calculateTimeRemaining
import com.example.web.WebCountdownGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testCountdownTimeRemainingCalculation() {
    val now = 1000000L
    val target = now + (3 * 86400 * 1000L) + (5 * 3600 * 1000L) + (12 * 60 * 1000L) + (45 * 1000L)
    val remaining = calculateTimeRemaining(target, now)
    assertEquals(3L, remaining.days)
    assertEquals(5L, remaining.hours)
    assertEquals(12L, remaining.minutes)
    assertEquals(45L, remaining.seconds)
    assertEquals(false, remaining.isPast)
  }

  @Test
  fun testCountdownPastEventCalculation() {
    val now = 2000000L
    val target = now - (1 * 86400 * 1000L)
    val remaining = calculateTimeRemaining(target, now)
    assertEquals(1L, remaining.days)
    assertEquals(true, remaining.isPast)
  }

  @Test
  fun testHtmlGeneratorOutput() {
    val countdown = CountdownEntity(
      id = 1,
      title = "Fiesta de Cumpleaños",
      antetitulo = "GRAN NOCHE",
      lugar = "Cinépolis Sala VIP",
      imageUrl = "https://example.com/poster.jpg",
      targetTimestamp = System.currentTimeMillis() + 86400000L,
      extraSubtitle = "Ven a celebrar con nosotros",
      extraMessage = "Traer traje de baño",
      textColorHex = "#00FFFF",
      effectColorHex = "#00FF66"
    )
    val html = WebCountdownGenerator.generateHtml(countdown)
    assertNotNull(html)
    assertTrue(html.contains("Fiesta de Cumpleaños"))
    assertTrue(html.contains("GRAN NOCHE"))
    assertTrue(html.contains("Cinépolis Sala VIP"))
    assertTrue(html.contains("https://example.com/poster.jpg"))
    assertTrue(html.contains("Ven a celebrar con nosotros"))
    assertTrue(html.contains("#00FF66"))
    assertTrue(html.contains("<canvas id=\"effect-canvas\">"))
  }
}
