package com.example.effects

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.data.model.VisualEffectType
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun CountdownEffectOverlay(
    effectType: VisualEffectType,
    effectColor: Color,
    speed: Float = 1.0f,
    intensity: Float = 1.0f,
    modifier: Modifier = Modifier.fillMaxSize()
) {
    val durationBase = (3000 / speed.coerceIn(0.3f, 3.0f)).toInt()
    val transition = rememberInfiniteTransition(label = "effect_transition")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = durationBase, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    val random = remember { Random(42) }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        if (w <= 0f || h <= 0f) return@Canvas

        when (effectType) {
            VisualEffectType.NEON_PULSE -> drawNeonPulse(phase, effectColor, intensity)
            VisualEffectType.SHADOW_FLICKER -> drawShadowFlicker(phase, effectColor, intensity, random)
            VisualEffectType.CYBER_GLITCH -> drawCyberGlitch(phase, effectColor, intensity, random)
            VisualEffectType.CONFETTI_SHOWER -> drawConfettiShower(phase, effectColor, intensity)
            VisualEffectType.FLOATING_FIREFLIES -> drawFloatingFireflies(phase, effectColor, intensity)
            VisualEffectType.COSMIC_STARDUST -> drawCosmicStardust(phase, effectColor, intensity)
            VisualEffectType.FLOATING_BUBBLES -> drawFloatingBubbles(phase, effectColor, intensity)
            VisualEffectType.MATRIX_RAIN -> drawMatrixRain(phase, effectColor, intensity)
            VisualEffectType.RETRO_CRT_SCANLINES -> drawRetroCrt(phase, effectColor, intensity)
            VisualEffectType.LIQUID_RIPPLE -> drawLiquidRipple(phase, effectColor, intensity)
            VisualEffectType.FIRE_EMBERS -> drawFireEmbers(phase, effectColor, intensity)
            VisualEffectType.CHROMA_RAINBOW_SHIFT -> drawRainbowShift(phase, intensity)
            VisualEffectType.DISCO_STROBE -> drawDiscoStrobe(phase, effectColor, intensity)
            VisualEffectType.AURORA_BOREALIS -> drawAuroraBorealis(phase, effectColor, intensity)
            VisualEffectType.SNOWFALL_FROST -> drawSnowfallFrost(phase, effectColor, intensity)
            VisualEffectType.ELECTRIC_LIGHTNING -> drawElectricLightning(phase, effectColor, intensity, random)
            VisualEffectType.HEARTBEAT_ZOOM -> drawHeartbeatZoom(phase, effectColor, intensity)
            VisualEffectType.GOLDEN_BOKEH -> drawGoldenBokeh(phase, effectColor, intensity)
            VisualEffectType.HOLOGRAM_SCAN -> drawHologramScan(phase, effectColor, intensity)
            VisualEffectType.POP_ART_DOTS -> drawPopArtDots(phase, effectColor, intensity)
        }
    }
}

// 1. NEON PULSE
private fun DrawScope.drawNeonPulse(phase: Float, color: Color, intensity: Float) {
    val center = Offset(size.width / 2f, size.height / 2f)
    val maxRadius = (size.width.coerceAtLeast(size.height)) * 0.6f
    val ringCount = (4 * intensity).toInt().coerceIn(2, 6)

    for (i in 0 until ringCount) {
        val currentProgress = (phase + i.toFloat() / ringCount) % 1f
        val r = currentProgress * maxRadius
        val alpha = ((1f - currentProgress) * 0.7f * intensity).coerceIn(0f, 1f)
        drawCircle(
            color = color.copy(alpha = alpha),
            radius = r,
            center = center,
            style = Stroke(width = 4f + (1f - currentProgress) * 12f)
        )
    }
}

// 2. SHADOW FLICKER
private fun DrawScope.drawShadowFlicker(phase: Float, color: Color, intensity: Float, random: Random) {
    val jitter = (sin(phase * 20f * PI.toFloat()) + cos(phase * 13f * PI.toFloat())) * 0.5f
    val flickerAlpha = ((0.3f + jitter * 0.25f) * intensity).coerceIn(0.05f, 0.85f)
    val cx = size.width / 2f
    val cy = size.height / 2f

    // Ambient flickering shadow aura
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(color.copy(alpha = flickerAlpha * 0.5f), Color.Transparent),
            center = Offset(cx + jitter * 20f, cy + jitter * 15f),
            radius = size.width * 0.6f
        ),
        size = size
    )
    // Flickering perimeter edge glow
    val strokeW = (6f + jitter * 4f) * intensity
    drawRect(
        color = color.copy(alpha = flickerAlpha * 0.7f),
        style = Stroke(width = strokeW),
        size = size
    )
}

// 3. CYBER GLITCH
private fun DrawScope.drawCyberGlitch(phase: Float, color: Color, intensity: Float, random: Random) {
    val lineCount = (12 * intensity).toInt().coerceIn(5, 30)
    for (i in 0 until lineCount) {
        val y = ((i.toFloat() / lineCount) * size.height + phase * 200f) % size.height
        val glitchWidth = (random.nextFloat() * size.width * 0.7f + 50f) * intensity
        val x = (random.nextFloat() * (size.width - glitchWidth)).coerceAtLeast(0f)
        val h = random.nextFloat() * 6f + 2f
        val altColor = if (i % 2 == 0) color.copy(alpha = 0.6f) else Color.Cyan.copy(alpha = 0.5f)
        drawRect(
            color = altColor,
            topLeft = Offset(x, y),
            size = Size(glitchWidth, h)
        )
    }
}

// 4. CONFETTI SHOWER
private fun DrawScope.drawConfettiShower(phase: Float, color: Color, intensity: Float) {
    val count = (35 * intensity).toInt().coerceIn(15, 60)
    val colors = listOf(color, Color(0xFFFFD700), Color(0xFFFF4081), Color(0xFF00E5FF), Color(0xFF76FF03))
    for (i in 0 until count) {
        val seed = i * 137.5f
        val startX = (seed % size.width)
        val fallSpeed = 1f + (i % 5) * 0.25f
        val y = ((phase * fallSpeed + (i.toFloat() / count)) % 1f) * (size.height + 60f) - 30f
        val wobble = sin(y * 0.05f + seed) * 20f
        val rotation = (y * 2f + seed) % 360f
        val c = colors[i % colors.size].copy(alpha = 0.85f)
        drawCircle(
            color = c,
            radius = (4f + (i % 4) * 2f) * intensity,
            center = Offset(startX + wobble, y)
        )
    }
}

// 5. FLOATING FIREFLIES
private fun DrawScope.drawFloatingFireflies(phase: Float, color: Color, intensity: Float) {
    val count = (25 * intensity).toInt().coerceIn(10, 45)
    for (i in 0 until count) {
        val baseAngle = (i.toFloat() / count) * 2f * PI.toFloat()
        val wanderX = sin(phase * 2f * PI.toFloat() + baseAngle) * (size.width * 0.35f) + size.width / 2f
        val wanderY = cos(phase * 1.5f * PI.toFloat() + baseAngle * 1.3f) * (size.height * 0.35f) + size.height / 2f
        val pulse = (sin(phase * 6f * PI.toFloat() + i) * 0.5f + 0.5f)
        val alpha = (pulse * 0.8f * intensity).coerceIn(0.1f, 1f)

        // Outer glow
        drawCircle(
            color = color.copy(alpha = alpha * 0.35f),
            radius = 16f * intensity,
            center = Offset(wanderX, wanderY)
        )
        // Core spark
        drawCircle(
            color = Color.White.copy(alpha = alpha),
            radius = 4f * intensity,
            center = Offset(wanderX, wanderY)
        )
    }
}

// 6. COSMIC STARDUST
private fun DrawScope.drawCosmicStardust(phase: Float, color: Color, intensity: Float) {
    val count = (40 * intensity).toInt().coerceIn(20, 70)
    val cx = size.width / 2f
    val cy = size.height / 2f
    val maxDist = size.width.coerceAtLeast(size.height) * 0.75f

    for (i in 0 until count) {
        val angle = (i.toFloat() / count) * 2f * PI.toFloat()
        val progress = (phase + (i * 0.17f)) % 1f
        val dist = progress * progress * maxDist
        val x = cx + cos(angle) * dist
        val y = cy + sin(angle) * dist
        val sizeStar = (2f + progress * 6f) * intensity
        val trailLen = progress * 24f * intensity

        drawLine(
            color = color.copy(alpha = progress * 0.8f),
            start = Offset(x, y),
            end = Offset(x - cos(angle) * trailLen, y - sin(angle) * trailLen),
            strokeWidth = sizeStar * 0.6f
        )
    }
}

// 7. FLOATING BUBBLES
private fun DrawScope.drawFloatingBubbles(phase: Float, color: Color, intensity: Float) {
    val count = (20 * intensity).toInt().coerceIn(8, 35)
    for (i in 0 until count) {
        val xSeed = (i * 123.4f) % size.width
        val speedMod = 0.8f + (i % 4) * 0.3f
        val y = (1f - ((phase * speedMod + (i.toFloat() / count)) % 1f)) * (size.height + 100f) - 50f
        val wobble = sin(y * 0.03f + i) * 15f
        val bubbleRadius = (14f + (i % 5) * 6f) * intensity

        // Bubble ring
        drawCircle(
            color = color.copy(alpha = 0.45f),
            radius = bubbleRadius,
            center = Offset(xSeed + wobble, y),
            style = Stroke(width = 2.5f)
        )
        // Bubble highlight reflection
        drawCircle(
            color = Color.White.copy(alpha = 0.6f),
            radius = bubbleRadius * 0.25f,
            center = Offset(xSeed + wobble - bubbleRadius * 0.35f, y - bubbleRadius * 0.35f)
        )
    }
}

// 8. MATRIX RAIN
private fun DrawScope.drawMatrixRain(phase: Float, color: Color, intensity: Float) {
    val columns = (16 * intensity).toInt().coerceIn(8, 30)
    val colWidth = size.width / columns

    for (col in 0 until columns) {
        val colSpeed = 1f + (col % 5) * 0.25f
        val headY = ((phase * colSpeed + (col * 0.13f)) % 1f) * (size.height + 200f) - 100f
        val x = col * colWidth + colWidth / 2f
        val streamLength = 180f * intensity

        // Gradient trail
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, color.copy(alpha = 0.6f), Color.White),
                startY = headY - streamLength,
                endY = headY
            ),
            topLeft = Offset(x - 3f, (headY - streamLength).coerceAtLeast(0f)),
            size = Size(6f, streamLength.coerceAtMost(size.height))
        )
        // Leading droplet
        drawCircle(
            color = Color.White,
            radius = 4f,
            center = Offset(x, headY)
        )
    }
}

// 9. RETRO CRT SCANLINES
private fun DrawScope.drawRetroCrt(phase: Float, color: Color, intensity: Float) {
    val step = 8f
    val scanY = (phase * size.height) % size.height
    // Scanline bar
    drawRect(
        color = color.copy(alpha = 0.25f * intensity),
        topLeft = Offset(0f, scanY - 30f),
        size = Size(size.width, 60f)
    )
    // Horizontal phosphor stripes
    var y = 0f
    while (y < size.height) {
        drawLine(
            color = Color.Black.copy(alpha = 0.35f * intensity),
            start = Offset(0f, y),
            end = Offset(size.width, y),
            strokeWidth = 2f
        )
        y += step
    }
}

// 10. LIQUID RIPPLE
private fun DrawScope.drawLiquidRipple(phase: Float, color: Color, intensity: Float) {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val maxRadius = size.width.coerceAtLeast(size.height) * 0.7f
    val waves = (5 * intensity).toInt().coerceIn(2, 7)

    for (i in 0 until waves) {
        val p = (phase + i.toFloat() / waves) % 1f
        val r = p * maxRadius
        val alpha = ((1f - p) * 0.6f * intensity).coerceIn(0f, 1f)
        drawCircle(
            color = color.copy(alpha = alpha),
            radius = r,
            center = Offset(cx, cy),
            style = Stroke(width = 3f + (1f - p) * 8f)
        )
    }
}

// 11. FIRE EMBERS
private fun DrawScope.drawFireEmbers(phase: Float, color: Color, intensity: Float) {
    val count = (35 * intensity).toInt().coerceIn(15, 60)
    for (i in 0 until count) {
        val seed = i * 73.1f
        val xBase = (seed % size.width)
        val speedMod = 1f + (i % 4) * 0.3f
        val progress = (phase * speedMod + (i.toFloat() / count)) % 1f
        val y = size.height * (1f - progress)
        val turbulence = sin(y * 0.04f + seed) * 30f
        val emberColor = if (progress < 0.4f) Color(0xFFFFF0A0) else color
        val alpha = ((1f - progress) * 0.9f * intensity).coerceIn(0f, 1f)

        drawCircle(
            color = emberColor.copy(alpha = alpha),
            radius = (3f + (1f - progress) * 5f) * intensity,
            center = Offset(xBase + turbulence, y)
        )
    }
}

// 12. RAINBOW SHIFT
private fun DrawScope.drawRainbowShift(phase: Float, intensity: Float) {
    val rainbowColors = listOf(
        Color(0xFFFF0055), Color(0xFFFF9900), Color(0xFFFFFF00),
        Color(0xFF00FF66), Color(0xFF00CCFF), Color(0xFF9900FF),
        Color(0xFFFF0055)
    )
    val angle = phase * 360f
    val rad = angle * PI.toFloat() / 180f
    val cx = size.width / 2f
    val cy = size.height / 2f
    val offset = Offset(cos(rad) * cx, sin(rad) * cy)

    drawRect(
        brush = Brush.linearGradient(
            colors = rainbowColors.map { it.copy(alpha = 0.22f * intensity) },
            start = Offset(cx - offset.x, cy - offset.y),
            end = Offset(cx + offset.x, cy + offset.y)
        ),
        size = size,
        blendMode = BlendMode.Screen
    )
}

// 13. DISCO STROBE
private fun DrawScope.drawDiscoStrobe(phase: Float, color: Color, intensity: Float) {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val beams = 8
    val rotation = phase * 2f * PI.toFloat()

    for (b in 0 until beams) {
        val ang = rotation + (b.toFloat() / beams) * 2f * PI.toFloat()
        val len = size.width.coerceAtLeast(size.height)
        val endX = cx + cos(ang) * len
        val endY = cy + sin(ang) * len

        val path = Path().apply {
            moveTo(cx, cy)
            lineTo(endX + cos(ang + 0.1f) * 40f, endY + sin(ang + 0.1f) * 40f)
            lineTo(endX - cos(ang - 0.1f) * 40f, endY - sin(ang - 0.1f) * 40f)
            close()
        }
        drawPath(
            path = path,
            color = color.copy(alpha = 0.12f * intensity)
        )
    }
}

// 14. AURORA BOREALIS
private fun DrawScope.drawAuroraBorealis(phase: Float, color: Color, intensity: Float) {
    val waves = 3
    for (w in 0 until waves) {
        val waveColor = if (w == 0) color else if (w == 1) Color(0xFF00FFCC) else Color(0xFF9D00FF)
        val path = Path()
        val baseY = size.height * (0.25f + w * 0.15f)
        path.moveTo(0f, baseY)

        var x = 0f
        val step = 20f
        while (x <= size.width) {
            val y = baseY + sin((x / size.width * 4f * PI.toFloat()) + phase * 2f * PI.toFloat() + w) * 40f
            path.lineTo(x, y)
            x += step
        }
        path.lineTo(size.width, size.height)
        path.lineTo(0f, size.height)
        path.close()

        drawPath(
            path = path,
            brush = Brush.verticalGradient(
                colors = listOf(waveColor.copy(alpha = 0.35f * intensity), Color.Transparent),
                startY = baseY - 50f,
                endY = baseY + 200f
            )
        )
    }
}

// 15. SNOWFALL FROST
private fun DrawScope.drawSnowfallFrost(phase: Float, color: Color, intensity: Float) {
    val count = (40 * intensity).toInt().coerceIn(15, 60)
    for (i in 0 until count) {
        val xBase = (i * 97.3f) % size.width
        val speedMod = 0.6f + (i % 3) * 0.4f
        val y = ((phase * speedMod + (i.toFloat() / count)) % 1f) * (size.height + 40f) - 20f
        val sway = sin(y * 0.05f + i) * 18f
        val flakeRadius = (2.5f + (i % 4) * 1.5f) * intensity

        drawCircle(
            color = Color.White.copy(alpha = 0.75f),
            radius = flakeRadius,
            center = Offset(xBase + sway, y)
        )
    }
}

// 16. ELECTRIC LIGHTNING
private fun DrawScope.drawElectricLightning(phase: Float, color: Color, intensity: Float, random: Random) {
    // Only flash during certain phase intervals
    val flash = (phase * 10f) % 1f
    if (flash > 0.45f) return // intermittent bursts

    val bolts = (2 * intensity).toInt().coerceIn(1, 4)
    for (b in 0 until bolts) {
        val path = Path()
        var curX = random.nextFloat() * size.width
        var curY = 0f
        path.moveTo(curX, curY)

        while (curY < size.height) {
            val stepY = random.nextFloat() * 40f + 20f
            val stepX = (random.nextFloat() - 0.5f) * 60f
            curX = (curX + stepX).coerceIn(0f, size.width)
            curY += stepY
            path.lineTo(curX, curY)
        }

        drawPath(
            path = path,
            color = color.copy(alpha = 0.8f * intensity),
            style = Stroke(width = 3.5f * intensity)
        )
        drawPath(
            path = path,
            color = Color.White,
            style = Stroke(width = 1.5f)
        )
    }
}

// 17. HEARTBEAT ZOOM
private fun DrawScope.drawHeartbeatZoom(phase: Float, color: Color, intensity: Float) {
    val cx = size.width / 2f
    val cy = size.height / 2f
    // Two-thump cardiac wave
    val p = (phase * 2f) % 1f
    val scale = if (p < 0.2f) {
        sin(p / 0.2f * PI.toFloat()) * 0.15f
    } else if (p in 0.25f..0.45f) {
        sin((p - 0.25f) / 0.2f * PI.toFloat()) * 0.08f
    } else 0f

    val radius = (size.width.coerceAtLeast(size.height) * 0.45f) * (1f + scale)
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(color.copy(alpha = (0.4f + scale * 1.5f) * intensity), Color.Transparent),
            center = Offset(cx, cy),
            radius = radius
        ),
        radius = radius,
        center = Offset(cx, cy)
    )
}

// 18. GOLDEN BOKEH
private fun DrawScope.drawGoldenBokeh(phase: Float, color: Color, intensity: Float) {
    val count = (18 * intensity).toInt().coerceIn(8, 30)
    for (i in 0 until count) {
        val xSeed = (i * 157.3f) % size.width
        val ySeed = (i * 211.7f) % size.height
        val driftX = sin(phase * 2f * PI.toFloat() + i) * 30f
        val driftY = cos(phase * 1.8f * PI.toFloat() + i) * 30f
        val radius = (25f + (i % 6) * 15f) * intensity
        val alpha = (0.2f + (sin(phase * 4f + i) * 0.1f)) * intensity

        drawCircle(
            color = color.copy(alpha = alpha.coerceIn(0.05f, 0.6f)),
            radius = radius,
            center = Offset(xSeed + driftX, ySeed + driftY)
        )
    }
}

// 19. HOLOGRAM SCAN
private fun DrawScope.drawHologramScan(phase: Float, color: Color, intensity: Float) {
    val scanY = phase * size.height
    // Main scanner beam
    drawLine(
        color = color.copy(alpha = 0.9f * intensity),
        start = Offset(0f, scanY),
        end = Offset(size.width, scanY),
        strokeWidth = 3f * intensity
    )
    // Beam glow tail
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(color.copy(alpha = 0.35f * intensity), Color.Transparent),
            startY = scanY,
            endY = scanY + 60f
        ),
        topLeft = Offset(0f, scanY),
        size = Size(size.width, 60f)
    )
    // HUD corner markers
    val bracketSize = 35f
    val stroke = Stroke(width = 3f)
    drawPath(Path().apply {
        moveTo(20f, 20f + bracketSize); lineTo(20f, 20f); lineTo(20f + bracketSize, 20f)
    }, color = color.copy(alpha = 0.7f), style = stroke)
    drawPath(Path().apply {
        moveTo(size.width - 20f - bracketSize, 20f); lineTo(size.width - 20f, 20f); lineTo(size.width - 20f, 20f + bracketSize)
    }, color = color.copy(alpha = 0.7f), style = stroke)
}

// 20. POP ART DOTS
private fun DrawScope.drawPopArtDots(phase: Float, color: Color, intensity: Float) {
    val spacing = 32f
    val cols = (size.width / spacing).toInt() + 1
    val rows = (size.height / spacing).toInt() + 1

    for (c in 0 until cols) {
        for (r in 0 until rows) {
            val cx = c * spacing
            val cy = r * spacing
            val dist = kotlin.math.hypot(cx - size.width / 2f, cy - size.height / 2f)
            val wave = sin((dist * 0.03f) - phase * 4f * PI.toFloat()) * 0.5f + 0.5f
            val dotRadius = (2f + wave * 6f) * intensity

            drawCircle(
                color = color.copy(alpha = 0.35f * wave),
                radius = dotRadius,
                center = Offset(cx, cy)
            )
        }
    }
}
