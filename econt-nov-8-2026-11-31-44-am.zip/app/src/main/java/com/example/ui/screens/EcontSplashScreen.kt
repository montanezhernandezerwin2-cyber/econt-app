package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/**
 * Animated intro splash for ECONT with Liquid Glass aesthetic.
 * Displays the radiant "E", "ECONT", and the requested teaser code:
 * 0 MESES · 1 DÍA · 6 HORAS · 6 MIN (0 1 6 6) with animated live seconds.
 */
@Composable
fun EcontSplashScreen(
    onFinished: () -> Unit
) {
    val scale = remember { Animatable(0.4f) }
    val alpha = remember { Animatable(0f) }
    val textAlpha = remember { Animatable(0f) }
    val countdownAlpha = remember { Animatable(0f) }

    // Live seconds tick
    var secondsLeft by remember { mutableIntStateOf(6) }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_pulse"
    )

    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ring_rotation"
    )

    LaunchedEffect(Unit) {
        // Entrance animation
        scale.animateTo(1f, animationSpec = tween(650, easing = FastOutSlowInEasing))
        alpha.animateTo(1f, animationSpec = tween(400))
        textAlpha.animateTo(1f, animationSpec = tween(400))
        countdownAlpha.animateTo(1f, animationSpec = tween(450))

        // Decrement seconds in live preview
        for (s in 6 downTo 0) {
            secondsLeft = s
            delay(1000)
        }

        delay(350)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF0D1B2A),
                        Color(0xFF060A13),
                        Color(0xFF020408)
                    ),
                    center = Offset(500f, 600f),
                    radius = 900f
                )
            )
            .clickable { onFinished() }
            .testTag("econt_splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        // Ambient background glow
        Box(
            modifier = Modifier
                .size(340.dp)
                .scale(pulseGlow)
                .drawBehind {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF00FF88).copy(alpha = 0.14f),
                                Color(0xFF00E5FF).copy(alpha = 0.08f),
                                Color.Transparent
                            )
                        )
                    )
                }
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            // Liquid Glass Icon Container
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .scale(scale.value)
                    .clip(RoundedCornerShape(36.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF132238).copy(alpha = 0.85f),
                                Color(0xFF08101E).copy(alpha = 0.95f)
                            )
                        )
                    )
                    .border(
                        width = 2.dp,
                        brush = Brush.sweepGradient(
                            listOf(
                                Color(0xFF00FF88),
                                Color(0xFF00E5FF),
                                Color(0xFF76FF03),
                                Color(0xFF00FF88)
                            )
                        ),
                        shape = RoundedCornerShape(36.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                // The radiant letter "E"
                Text(
                    text = "E",
                    style = TextStyle(
                        fontSize = 66.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.SansSerif,
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF00FF88),
                                Color(0xFF00E5FF)
                            )
                        )
                    ),
                    modifier = Modifier.scale(pulseGlow)
                )
            }

            Spacer(modifier = Modifier.height(22.dp))

            // App Name "ECONT"
            Text(
                text = "ECONT",
                fontSize = 36.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 8.sp,
                color = Color.White,
                modifier = Modifier.scale(textAlpha.value)
            )

            Text(
                text = "ORGANIZA TUS MOMENTOS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 3.sp,
                color = Color(0xFF00FF88).copy(alpha = 0.9f),
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(32.dp))

            // The Liquid Glass Teaser Box forming 0 1 6 6:
            // 0 MESES : 1 DÍA : 6 HORAS : 6 MIN + animated SEG
            Box(
                modifier = Modifier
                    .scale(countdownAlpha.value)
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xFF131F33).copy(alpha = 0.75f),
                                Color(0xFF0A101C).copy(alpha = 0.85f)
                            )
                        )
                    )
                    .border(
                        1.2.dp,
                        Brush.linearGradient(
                            listOf(
                                Color(0xFF00FF88).copy(alpha = 0.6f),
                                Color(0xFF00E5FF).copy(alpha = 0.3f),
                                Color.White.copy(alpha = 0.2f)
                            )
                        ),
                        RoundedCornerShape(24.dp)
                    )
                    .padding(horizontal = 18.dp, vertical = 14.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00FF88))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "CÓDIGO INICIAL · 0166",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp,
                            color = Color(0xFF38BDF8)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SplashUnit("0", "MESES", isHighlight = true)
                        SplashSeparator()
                        SplashUnit("1", "DÍA", isHighlight = true)
                        SplashSeparator()
                        SplashUnit("6", "HORAS", isHighlight = true)
                        SplashSeparator()
                        SplashUnit("6", "MIN", isHighlight = true)
                        SplashSeparator()
                        SplashUnit(String.format("%02d", secondsLeft), "SEG", isAccent = true)
                    }
                }
            }

            Spacer(modifier = Modifier.height(26.dp))

            Text(
                text = "Toca la pantalla para continuar",
                fontSize = 11.sp,
                color = Color(0xFF64748B),
                letterSpacing = 1.sp
            )
        }
    }
}

@Composable
private fun SplashUnit(
    value: String,
    label: String,
    isHighlight: Boolean = false,
    isAccent: Boolean = false
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (isHighlight) Color(0xFF00FF88).copy(alpha = 0.12f)
                else if (isAccent) Color(0xFF00E5FF).copy(alpha = 0.15f)
                else Color.Transparent
            )
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = value,
            fontSize = 22.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            color = when {
                isAccent -> Color(0xFF00E5FF)
                isHighlight -> Color(0xFF00FF88)
                else -> Color.White
            }
        )
        Text(
            text = label,
            fontSize = 8.5.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF94A3B8)
        )
    }
}

@Composable
private fun SplashSeparator() {
    Text(
        text = ":",
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF00FF88).copy(alpha = 0.5f),
        modifier = Modifier.padding(bottom = 8.dp)
    )
}
