package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Liquid Glass UI container:
 * Frosted translucent acrylic surface, glossy specular top highlight,
 * subtle luminous glass border, and soft depth shadows.
 */
@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    tintColor: Color = Color(0xFF00FF88),
    borderAlpha: Float = 0.28f,
    backgroundAlpha: Float = 0.55f,
    contentPadding: Dp = 16.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val glassBg = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF131D31).copy(alpha = backgroundAlpha),
            Color(0xFF0A0F1D).copy(alpha = backgroundAlpha * 1.15f)
        )
    )

    val glassBorder = Brush.linearGradient(
        colors = listOf(
            Color.White.copy(alpha = borderAlpha * 1.2f),
            tintColor.copy(alpha = borderAlpha),
            Color.White.copy(alpha = borderAlpha * 0.3f),
            tintColor.copy(alpha = borderAlpha * 0.6f)
        ),
        start = Offset(0f, 0f),
        end = Offset(400f, 800f)
    )

    Box(
        modifier = modifier
            .clip(shape)
            .background(glassBg)
            .border(1.2.dp, glassBorder, shape)
            .drawBehind {
                // Subtle specular glossy reflection line along the top inner edge
                drawLine(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.25f),
                            tintColor.copy(alpha = 0.35f),
                            Color.Transparent
                        )
                    ),
                    start = Offset(size.width * 0.1f, 1.dp.toPx()),
                    end = Offset(size.width * 0.9f, 1.dp.toPx()),
                    strokeWidth = 1.2.dp.toPx()
                )
            }
            .padding(contentPadding)
    ) {
        content()
    }
}

/**
 * Modifier extension to easily apply a Liquid Glass style to any Box or Button.
 */
fun Modifier.liquidGlass(
    shape: Shape = RoundedCornerShape(16.dp),
    accentColor: Color = Color(0xFF00FF88),
    bgAlpha: Float = 0.6f,
    borderAlpha: Float = 0.3f
): Modifier = this
    .clip(shape)
    .background(
        Brush.verticalGradient(
            colors = listOf(
                Color(0xFF142036).copy(alpha = bgAlpha),
                Color(0xFF090E1A).copy(alpha = bgAlpha * 1.1f)
            )
        )
    )
    .border(
        width = 1.dp,
        brush = Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = borderAlpha),
                accentColor.copy(alpha = borderAlpha * 0.8f),
                Color.Transparent
            )
        ),
        shape = shape
    )
