package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun ChronoGlowTheme(
    selectedPalette: AppThemePalette = AppThemePalette.CYBER_NEON,
    content: @Composable () -> Unit
) {
    val colorScheme = darkColorScheme(
        primary = selectedPalette.primary,
        onPrimary = Color.Black,
        primaryContainer = selectedPalette.surfaceVariant,
        onPrimaryContainer = selectedPalette.primary,
        secondary = selectedPalette.secondary,
        onSecondary = Color.White,
        secondaryContainer = selectedPalette.surfaceVariant,
        onSecondaryContainer = selectedPalette.secondary,
        tertiary = selectedPalette.tertiary,
        onTertiary = Color.Black,
        background = selectedPalette.background,
        onBackground = Color(0xFFF1F5F9),
        surface = selectedPalette.surface,
        onSurface = Color(0xFFF8FAFC),
        surfaceVariant = selectedPalette.surfaceVariant,
        onSurfaceVariant = Color(0xFFCBD5E1),
        outline = selectedPalette.primary.copy(alpha = 0.35f)
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Backward compatibility alias
@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    ChronoGlowTheme(
        selectedPalette = AppThemePalette.CYBER_NEON,
        content = content
    )
}
