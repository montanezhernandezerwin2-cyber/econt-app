package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.audio.CountdownSoundPlayer
import com.example.data.model.BackgroundPreset
import com.example.data.model.CountdownEntity
import com.example.data.model.FontStylePreset
import com.example.data.model.SoundPreset
import com.example.data.model.VisualEffectType
import com.example.effects.CountdownEffectOverlay
import com.example.ui.components.TimeTickDisplay
import com.example.ui.components.WebPreviewDialog
import com.example.ui.components.calculateTimeRemaining
import com.example.web.WebCountdownGenerator
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun CountdownViewerScreen(
    countdown: CountdownEntity,
    onEdit: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val soundPlayer = remember { CountdownSoundPlayer(context) }
    var isSoundOn by remember { mutableStateOf(countdown.isSoundEnabled) }
    var showWebDialog by remember { mutableStateOf(false) }
    var showBoletasDialog by remember { mutableStateOf(false) }
    var showControls by remember { mutableStateOf(true) }

    var currentMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var lastSecond by remember { mutableLongStateOf(-1L) }

    val soundPreset = remember(countdown.soundPreset) {
        try { SoundPreset.valueOf(countdown.soundPreset) } catch (_: Exception) { SoundPreset.CLOCK_TICK }
    }
    val effectType = remember(countdown.effectType) {
        try { VisualEffectType.valueOf(countdown.effectType) } catch (_: Exception) { VisualEffectType.NEON_PULSE }
    }
    val fontPreset = remember(countdown.fontStyle) {
        try { FontStylePreset.valueOf(countdown.fontStyle) } catch (_: Exception) { FontStylePreset.CYBERPUNK }
    }
    val effectColor = remember(countdown.effectColorHex) {
        try { Color(android.graphics.Color.parseColor(countdown.effectColorHex)) } catch (_: Exception) { Color(0xFF00FF66) }
    }
    val textColor = remember(countdown.textColorHex) {
        try { Color(android.graphics.Color.parseColor(countdown.textColorHex)) } catch (_: Exception) { Color(0xFF99FFCC) }
    }

    // Stop audio immediately upon leaving the screen
    DisposableEffect(Unit) {
        onDispose {
            soundPlayer.stopAll()
        }
    }

    LaunchedEffect(isSoundOn) {
        if (!isSoundOn) {
            soundPlayer.stopAll()
        }
    }

    // Ticker loop with sounds ONLY PLAYING HERE when open and unmuted
    LaunchedEffect(countdown.id, isSoundOn) {
        while (true) {
            delay(200)
            val now = System.currentTimeMillis()
            currentMillis = now
            val totalSec = (countdown.targetTimestamp - now) / 1000
            if (totalSec != lastSecond && totalSec >= 0) {
                lastSecond = totalSec
                if (isSoundOn) {
                    soundPlayer.playTick(soundPreset, countdown.isVibrateEnabled)
                }
            }
        }
    }

    val remaining = remember(countdown.targetTimestamp, currentMillis) {
        calculateTimeRemaining(countdown.targetTimestamp, currentMillis)
    }

    val dateFormat = remember { SimpleDateFormat("dd MMMM yyyy · h:mm a", Locale("es", "ES")) }
    val formattedTarget = remember(countdown.targetTimestamp) {
        dateFormat.format(countdown.targetTimestamp).uppercase(Locale("es", "ES"))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                showControls = !showControls
            }
    ) {
        // Background layer: URL image or preset
        if (countdown.imageUrl.isNotBlank()) {
            AsyncImage(
                model = countdown.imageUrl,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.65f)))
        } else if (countdown.backgroundPreset == BackgroundPreset.CUSTOM_IMAGE.name && countdown.customImageUri != null) {
            AsyncImage(
                model = countdown.customImageUri,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.65f)))
        } else {
            // Emerald/cyan geometric gradient matching Screenshot 2
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        androidx.compose.ui.graphics.Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF0A2B1D),
                                Color(0xFF07141E),
                                Color(0xFF040810)
                            )
                        )
                    )
            )
        }

        // Live visual effect overlay
        CountdownEffectOverlay(
            effectType = effectType,
            effectColor = effectColor,
            speed = countdown.effectSpeed,
            intensity = countdown.effectIntensity
        )

        // Main Content (Exact layout and hierarchy from prototype screenshot 2)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar Navigation
            AnimatedVisibility(
                visible = showControls,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            soundPlayer.stopAll()
                            onBack()
                        },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.5f))
                            .testTag("viewer_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Regresar",
                            tint = Color.White
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(
                            onClick = { isSoundOn = !isSoundOn },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.5f))
                                .testTag("viewer_toggle_sound_button")
                        ) {
                            Icon(
                                imageVector = if (isSoundOn) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                                contentDescription = "Sonido",
                                tint = if (isSoundOn) effectColor else Color.Gray
                            )
                        }

                        IconButton(
                            onClick = onEdit,
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.5f))
                                .testTag("viewer_edit_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Editar",
                                tint = Color.White
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Textual Hierarchy matching Screenshot 2
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Antetítulo: e.g. MARVEL STUDIOS · EVENT COUNTDOWN
                val antetituloText = if (countdown.antetitulo.isNotBlank()) {
                    countdown.antetitulo
                } else {
                    "${countdown.category.uppercase()} · EVENT COUNTDOWN"
                }
                Text(
                    text = antetituloText.uppercase(),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFA7F3D0),
                    letterSpacing = 4.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Giant Display Title: e.g. DOOMSDAY
                Text(
                    text = countdown.title.uppercase(),
                    fontSize = 42.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.SansSerif,
                    color = textColor,
                    letterSpacing = 4.sp,
                    textAlign = TextAlign.Center
                )

                // Subtítulo: e.g. IS COMING
                if (countdown.extraSubtitle.isNotBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = countdown.extraSubtitle.uppercase(),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFD1FAE5),
                        letterSpacing = 6.sp,
                        textAlign = TextAlign.Center
                    )
                }

                // Lugar: e.g. VILLAVICENCIO · DINAMIX · EXPERIENCIA 3D
                if (countdown.lugar.isNotBlank()) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = countdown.lugar.uppercase(),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF6EE7B7),
                        letterSpacing = 3.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 2x2 Countdown Grid from Screenshot 2
            TimeTickDisplay(
                timeRemaining = remaining,
                fontStylePreset = fontPreset,
                textColor = textColor,
                accentGlowColor = effectColor,
                is2x2Grid = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Target Date Footer: e.g. 16 DICIEMBRE 2026 · 1:45 PM
            Text(
                text = formattedTarget,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFE2E8F0),
                letterSpacing = 2.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Action Buttons from Screenshot 2: [🎟️ MIS BOLETAS] [⚙️ PERSONALIZAR]
            AnimatedVisibility(
                visible = showControls,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // MIS BOLETAS / DETALLES
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFF0F172A).copy(alpha = 0.85f))
                                .border(1.5.dp, Color(0xFF00FF88).copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                                .clickable { showBoletasDialog = true }
                                .testTag("viewer_boletas_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("🎟️", fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "MIS BOLETAS",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp,
                                    color = Color.White,
                                    letterSpacing = 1.sp
                                )
                            }
                        }

                        // PERSONALIZAR
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFF0F172A).copy(alpha = 0.85f))
                                .border(1.5.dp, Color(0xFF00FF88).copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                                .clickable {
                                    soundPlayer.stopAll()
                                    onEdit()
                                }
                                .testTag("viewer_personalizar_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Settings, contentDescription = null, tint = Color(0xFF00FF88), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "PERSONALIZAR",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp,
                                    color = Color.White,
                                    letterSpacing = 1.sp
                                )
                            }
                        }
                    }

                    // SITIO WEB ACTIONS
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { showWebDialog = true },
                            modifier = Modifier.weight(1f).height(46.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Sitio Web", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                try {
                                    val file = WebCountdownGenerator.exportToFile(context, countdown)
                                    val uri = WebCountdownGenerator.getShareableUri(context, file)
                                    val browserIntent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(uri, "text/html")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(browserIntent, "Abrir con Navegador"))
                                } catch (e: Exception) {
                                    showWebDialog = true
                                }
                            },
                            modifier = Modifier.weight(1f).height(46.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Default.OpenInBrowser, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Navegador", fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Modal "Mis Boletas / Detalles del Evento"
    if (showBoletasDialog) {
        Dialog(onDismissRequest = { showBoletasDialog = false }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(26.dp)),
                color = Color(0xFF0F172A)
            ) {
                Column(modifier = Modifier.padding(22.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🎟️", fontSize = 24.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Mis Boletas y Detalles",
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                color = Color.White
                            )
                        }
                        IconButton(onClick = { showBoletasDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Cerrar", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = countdown.title.uppercase(),
                        fontWeight = FontWeight.Black,
                        fontSize = 17.sp,
                        color = Color(0xFF00FF88)
                    )

                    if (countdown.lugar.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "📍 ${countdown.lugar}",
                            fontSize = 13.sp,
                            color = Color(0xFF38BDF8),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "🗓️ $formattedTarget",
                        fontSize = 12.sp,
                        color = Color(0xFFCBD5E1)
                    )

                    if (countdown.extraMessage.isNotBlank()) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "Instrucciones / Notas de Boletos:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF94A3B8)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = countdown.extraMessage,
                                    fontSize = 13.sp,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = { showBoletasDialog = false },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Entendido", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showWebDialog) {
        WebPreviewDialog(
            countdown = countdown,
            onDismiss = { showWebDialog = false }
        )
    }
}
