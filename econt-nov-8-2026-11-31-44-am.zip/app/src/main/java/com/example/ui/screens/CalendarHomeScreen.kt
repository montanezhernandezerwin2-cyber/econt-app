package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CalendarNoteEntity
import com.example.data.model.CalendarReminderEntity
import com.example.data.model.CountdownEntity
import com.example.ui.components.CreateNoteDialog
import com.example.ui.components.CreateReminderDialog
import com.example.ui.components.InteractiveCalendarView
import com.example.ui.components.ShinyGlowingButton
import com.example.ui.components.ThemeCustomizationDialog
import com.example.ui.components.WebPreviewDialog
import com.example.ui.components.calculateTimeRemaining
import com.example.ui.components.formatDateString
import com.example.ui.theme.AppThemePalette
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarHomeScreen(
    countdowns: List<CountdownEntity>,
    notes: List<CalendarNoteEntity>,
    reminders: List<CalendarReminderEntity>,
    currentPalette: AppThemePalette,
    onPaletteChanged: (AppThemePalette) -> Unit,
    onCreateCountdown: (String?) -> Unit,
    onViewCountdown: (CountdownEntity) -> Unit,
    onDeleteCountdown: (CountdownEntity) -> Unit,
    onSaveNote: (CalendarNoteEntity) -> Unit,
    onDeleteNote: (CalendarNoteEntity) -> Unit,
    onSaveReminder: (CalendarReminderEntity) -> Unit,
    onToggleReminder: (CalendarReminderEntity) -> Unit,
    onDeleteReminder: (CalendarReminderEntity) -> Unit
) {
    val todayCal = remember { Calendar.getInstance() }
    val initialDate = remember {
        formatDateString(
            todayCal.get(Calendar.YEAR),
            todayCal.get(Calendar.MONTH) + 1,
            todayCal.get(Calendar.DAY_OF_MONTH)
        )
    }

    var selectedDateString by remember { mutableStateOf(initialDate) }
    var currentYear by remember { mutableIntStateOf(todayCal.get(Calendar.YEAR)) }
    var currentMonth by remember { mutableIntStateOf(todayCal.get(Calendar.MONTH)) }

    // Top Level View: 0 = Calendario, 1 = Mis Cuentas (from screenshot 1)
    var topSectionTab by remember { mutableIntStateOf(0) }

    // Dialog toggles
    var showThemeDialog by remember { mutableStateOf(false) }
    var showNoteDialog by remember { mutableStateOf(false) }
    var showReminderDialog by remember { mutableStateOf(false) }
    var webPreviewCountdown by remember { mutableStateOf<CountdownEntity?>(null) }

    // Bottom tab for selected day in calendar view
    var daySubTab by remember { mutableIntStateOf(0) } // 0: Cuentas, 1: Notas, 2: Recordatorios

    // Mapping countdowns to dates
    val dateFormatYmd = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val countdownDates = remember(countdowns) {
        countdowns.map { dateFormatYmd.format(Date(it.targetTimestamp)) }.toSet()
    }
    val noteDates = remember(notes) {
        notes.map { it.dateString }.toSet()
    }
    val reminderDates = remember(reminders) {
        reminders.map { it.dateString }.toSet()
    }

    val dayNotes = remember(notes, selectedDateString) {
        notes.filter { it.dateString == selectedDateString }
    }
    val dayReminders = remember(reminders, selectedDateString) {
        reminders.filter { it.dateString == selectedDateString }
    }
    val dayCountdowns = remember(countdowns, selectedDateString) {
        countdowns.filter { dateFormatYmd.format(Date(it.targetTimestamp)) == selectedDateString }
    }

    val formattedSelectedDate = remember(selectedDateString) {
        try {
            val date = dateFormatYmd.parse(selectedDateString)
            val sdf = SimpleDateFormat("EEEE, dd 'de' MMMM yyyy", Locale("es", "ES"))
            sdf.format(date ?: Date()).replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
        } catch (_: Exception) {
            selectedDateString
        }
    }

    // Silent clock ticker for home cards (NO SOUND PLAYED ON HOME, exactly as requested)
    var currentMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            currentMillis = System.currentTimeMillis()
        }
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF060913))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Navigation Tabs matching Screenshot 1: [⏳ CALENDARIO] [⏱️ Mis cuentas]
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0F172A))
                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
                        .padding(3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (topSectionTab == 0) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clickable { topSectionTab = 0 }
                            .padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "⏳ CALENDARIO",
                            fontWeight = FontWeight.Black,
                            fontSize = 11.5.sp,
                            color = if (topSectionTab == 0) Color.Black else Color(0xFF94A3B8),
                            letterSpacing = 0.5.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (topSectionTab == 1) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clickable { topSectionTab = 1 }
                            .padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "⏱️ MIS CUENTAS (${countdowns.size})",
                            fontWeight = FontWeight.Black,
                            fontSize = 11.5.sp,
                            color = if (topSectionTab == 1) Color.Black else Color(0xFF94A3B8),
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                IconButton(
                    onClick = { showThemeDialog = true },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0F172A))
                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
                        .testTag("app_theme_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Palette,
                        contentDescription = "Personalizar Interfaz",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        },
        containerColor = Color(0xFF060913)
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // Headline matching Screenshot 1
            item {
                Column {
                    Text(
                        text = "ORGANIZA TUS MOMENTOS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF64748B),
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Tu tiempo, a tu manera.",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }
            }

            // Prominent Shiny Glowing Button to Create Countdown
            item {
                ShinyGlowingButton(
                    onClick = { onCreateCountdown(selectedDateString) },
                    glowColor = MaterialTheme.colorScheme.primary,
                    accentColor = MaterialTheme.colorScheme.secondary
                )
            }

            if (topSectionTab == 0) {
                // CALENDAR TAB
                item {
                    InteractiveCalendarView(
                        currentYearMonth = Pair(currentYear, currentMonth),
                        selectedDateString = selectedDateString,
                        countdownDates = countdownDates,
                        noteDates = noteDates,
                        reminderDates = reminderDates,
                        onDateSelected = { dateStr ->
                            selectedDateString = dateStr
                        },
                        onPrevMonth = {
                            if (currentMonth == 0) {
                                currentMonth = 11
                                currentYear -= 1
                            } else {
                                currentMonth -= 1
                            }
                        },
                        onNextMonth = {
                            if (currentMonth == 11) {
                                currentMonth = 0
                                currentYear += 1
                            } else {
                                currentMonth += 1
                            }
                        },
                        onTodayClicked = {
                            val now = Calendar.getInstance()
                            currentYear = now.get(Calendar.YEAR)
                            currentMonth = now.get(Calendar.MONTH)
                            selectedDateString = formatDateString(
                                now.get(Calendar.YEAR),
                                now.get(Calendar.MONTH) + 1,
                                now.get(Calendar.DAY_OF_MONTH)
                            )
                        }
                    )
                }

                // Selected Day Manager & Sub-tabs
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.8f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = formattedSelectedDate,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "Gestión del día seleccionado",
                                        fontSize = 11.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    IconButton(
                                        onClick = { showNoteDialog = true },
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f))
                                            .testTag("create_note_button")
                                    ) {
                                        Icon(
                                            Icons.Default.NoteAdd,
                                            contentDescription = "Crear Nota",
                                            tint = MaterialTheme.colorScheme.secondary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }

                                    IconButton(
                                        onClick = { showReminderDialog = true },
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f))
                                            .testTag("create_reminder_button")
                                    ) {
                                        Icon(
                                            Icons.Default.Alarm,
                                            contentDescription = "Crear Recordatorio",
                                            tint = MaterialTheme.colorScheme.tertiary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            TabRow(
                                selectedTabIndex = daySubTab,
                                containerColor = Color(0xFF1E293B),
                                contentColor = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.clip(RoundedCornerShape(12.dp))
                            ) {
                                Tab(
                                    selected = daySubTab == 0,
                                    onClick = { daySubTab = 0 },
                                    text = { Text("Cuentas (${dayCountdowns.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                                )
                                Tab(
                                    selected = daySubTab == 1,
                                    onClick = { daySubTab = 1 },
                                    text = { Text("Notas (${dayNotes.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                                )
                                Tab(
                                    selected = daySubTab == 2,
                                    onClick = { daySubTab = 2 },
                                    text = { Text("Recordatorios (${dayReminders.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                                )
                            }
                        }
                    }
                }

                // Day Sub-tab content
                when (daySubTab) {
                    0 -> {
                        if (dayCountdowns.isEmpty()) {
                            item {
                                EmptyStateCard(
                                    title = "Sin cuentas para este día",
                                    subtitle = "Toca el botón brillante para programar un evento o película para este día",
                                    icon = Icons.Default.Timer
                                )
                            }
                        } else {
                            items(dayCountdowns, key = { it.id }) { item ->
                                CountdownCardItem(
                                    countdown = item,
                                    currentMillis = currentMillis,
                                    onClick = { onViewCountdown(item) },
                                    onWebClick = { webPreviewCountdown = item },
                                    onDeleteClick = { onDeleteCountdown(item) }
                                )
                            }
                        }
                    }
                    1 -> {
                        if (dayNotes.isEmpty()) {
                            item {
                                EmptyStateCard(
                                    title = "No hay notas para este día",
                                    subtitle = "Toca el botón + para añadir notas sobre boletos, reservaciones o preparativos",
                                    icon = Icons.Default.EditNote
                                )
                            }
                        } else {
                            items(dayNotes, key = { it.id }) { note ->
                                NoteCardItem(note = note, onDelete = { onDeleteNote(note) })
                            }
                        }
                    }
                    2 -> {
                        if (dayReminders.isEmpty()) {
                            item {
                                EmptyStateCard(
                                    title = "Sin recordatorios para este día",
                                    subtitle = "Toca la alarma para programar avisos con horario y prioridad",
                                    icon = Icons.Default.NotificationsActive
                                )
                            }
                        } else {
                            items(dayReminders, key = { it.id }) { reminder ->
                                ReminderCardItem(
                                    reminder = reminder,
                                    onToggle = { onToggleReminder(reminder) },
                                    onDelete = { onDeleteReminder(reminder) }
                                )
                            }
                        }
                    }
                }
            } else {
                // "MIS CUENTAS" TAB - Shows all countdowns
                if (countdowns.isEmpty()) {
                    item {
                        EmptyStateCard(
                            title = "No hay cuentas regresivas creadas",
                            subtitle = "Toca 'Crear cuenta regresiva' para diseñar tu primer evento con fotos y efectos",
                            icon = Icons.Default.Timer
                        )
                    }
                } else {
                    items(countdowns, key = { it.id }) { item ->
                        CountdownCardItem(
                            countdown = item,
                            currentMillis = currentMillis,
                            onClick = { onViewCountdown(item) },
                            onWebClick = { webPreviewCountdown = item },
                            onDeleteClick = { onDeleteCountdown(item) }
                        )
                    }
                }
            }
        }
    }

    if (showThemeDialog) {
        ThemeCustomizationDialog(
            currentPalette = currentPalette,
            onPaletteSelected = {
                onPaletteChanged(it)
                showThemeDialog = false
            },
            onDismiss = { showThemeDialog = false }
        )
    }

    if (showNoteDialog) {
        CreateNoteDialog(
            dateString = selectedDateString,
            onSaveNote = onSaveNote,
            onDismiss = { showNoteDialog = false }
        )
    }

    if (showReminderDialog) {
        CreateReminderDialog(
            dateString = selectedDateString,
            onSaveReminder = onSaveReminder,
            onDismiss = { showReminderDialog = false }
        )
    }

    webPreviewCountdown?.let { countdown ->
        WebPreviewDialog(
            countdown = countdown,
            onDismiss = { webPreviewCountdown = null }
        )
    }
}

@Composable
private fun CountdownCardItem(
    countdown: CountdownEntity,
    currentMillis: Long,
    onClick: () -> Unit,
    onWebClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val remaining = remember(countdown.targetTimestamp, currentMillis) {
        calculateTimeRemaining(countdown.targetTimestamp, currentMillis)
    }

    val effectColor = remember(countdown.effectColorHex) {
        try { Color(android.graphics.Color.parseColor(countdown.effectColorHex)) } catch (_: Exception) { Color(0xFF00FF66) }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("countdown_card_${countdown.id}"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.85f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Category Badge + Web and Delete actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(effectColor)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = countdown.category.uppercase(),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = effectColor,
                        letterSpacing = 1.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onWebClick,
                        modifier = Modifier.size(32.dp).testTag("card_web_button_${countdown.id}")
                    ) {
                        Icon(
                            Icons.Default.Language,
                            contentDescription = "Sitio Web",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.size(32.dp).testTag("card_delete_button_${countdown.id}")
                    ) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Eliminar",
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Antetítulo if exists
            if (countdown.antetitulo.isNotBlank()) {
                Text(
                    text = countdown.antetitulo.uppercase(),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = effectColor,
                    letterSpacing = 1.sp
                )
            }

            // Title
            Text(
                text = countdown.title,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            // Lugar / Ubicación
            if (countdown.lugar.isNotBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                    Icon(
                        Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = countdown.lugar,
                        fontSize = 12.sp,
                        color = Color(0xFF38BDF8),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (countdown.extraSubtitle.isNotBlank()) {
                Text(
                    text = countdown.extraSubtitle,
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Time summary chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TimeBadge(value = remaining.days, label = "Días", modifier = Modifier.weight(1f))
                TimeBadge(value = remaining.hours, label = "Horas", modifier = Modifier.weight(1f))
                TimeBadge(value = remaining.minutes, label = "Min", modifier = Modifier.weight(1f))
                TimeBadge(value = remaining.seconds, label = "Seg", modifier = Modifier.weight(1f), isAccent = true)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Toca para pantalla completa ⛶",
                fontSize = 10.sp,
                color = Color(0xFF64748B),
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun TimeBadge(
    value: Long,
    label: String,
    modifier: Modifier = Modifier,
    isAccent: Boolean = false
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isAccent) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color(0xFF1E293B))
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = String.format("%02d", value),
                fontWeight = FontWeight.Black,
                fontSize = 17.sp,
                color = if (isAccent) MaterialTheme.colorScheme.primary else Color.White
            )
            Text(
                text = label,
                fontSize = 9.sp,
                color = Color(0xFF94A3B8),
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun NoteCardItem(
    note: CalendarNoteEntity,
    onDelete: () -> Unit
) {
    val tagColor = remember(note.colorHex) {
        try { Color(android.graphics.Color.parseColor(note.colorHex)) } catch (_: Exception) { Color(0xFF3B82F6) }
    }

    Card(
        modifier = Modifier.fillMaxWidth().testTag("note_card_${note.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(6.dp, 36.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(tagColor)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = note.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.White
                    )
                    if (note.content.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = note.content,
                            fontSize = 13.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
            }

            IconButton(onClick = onDelete, modifier = Modifier.size(30.dp)) {
                Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun ReminderCardItem(
    reminder: CalendarReminderEntity,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    val priorityColor = when (reminder.priority) {
        "Alta" -> Color(0xFFEF4444)
        "Normal" -> MaterialTheme.colorScheme.primary
        else -> Color(0xFF10B981)
    }

    Card(
        modifier = Modifier.fillMaxWidth().testTag("reminder_card_${reminder.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Checkbox(
                    checked = reminder.isCompleted,
                    onCheckedChange = { onToggle() },
                    colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
                )

                Column {
                    Text(
                        text = reminder.title,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        color = if (reminder.isCompleted) Color(0xFF64748B) else Color.White,
                        textDecoration = if (reminder.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = reminder.timeString,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(priorityColor.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = reminder.priority,
                                fontSize = 10.sp,
                                color = priorityColor,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            IconButton(onClick = onDelete, modifier = Modifier.size(30.dp)) {
                Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun EmptyStateCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A).copy(alpha = 0.6f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                modifier = Modifier.size(44.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = Color(0xFF94A3B8),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                lineHeight = 16.sp
            )
        }
    }
}
