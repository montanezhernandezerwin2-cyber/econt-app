package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class CalendarDayInfo(
    val year: Int,
    val month: Int, // 0-based
    val dayOfMonth: Int,
    val isCurrentMonth: Boolean,
    val isToday: Boolean,
    val dateString: String // "YYYY-MM-DD"
)

@Composable
fun InteractiveCalendarView(
    currentYearMonth: Pair<Int, Int>, // year, month (0-11)
    selectedDateString: String, // "YYYY-MM-DD"
    countdownDates: Set<String>,
    noteDates: Set<String>,
    reminderDates: Set<String>,
    onDateSelected: (String) -> Unit,
    onPrevMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onTodayClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (year, month) = currentYearMonth

    var selectedViewMode by remember { mutableStateOf("Mes") } // Mes, Semana, Día, Año

    val monthName = remember(year, month) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        val sdf = SimpleDateFormat("MMMM yyyy", Locale("es", "ES"))
        sdf.format(cal.time).replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
    }

    val daysInGrid = remember(year, month) {
        generateCalendarGrid(year, month)
    }

    // Exact single-letter weekdays matching screenshot: L, M, X, J, V, S, D
    val weekdays = listOf("L", "M", "X", "J", "V", "S", "D")

    val glassShape = RoundedCornerShape(26.dp)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(glassShape)
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF111D31).copy(alpha = 0.88f),
                        Color(0xFF080F1E).copy(alpha = 0.96f)
                    )
                )
            )
            .border(
                width = 1.2.dp,
                brush = Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = 0.28f),
                        Color(0xFF00FF88).copy(alpha = 0.25f),
                        Color(0xFF1E293B)
                    )
                ),
                shape = glassShape
            )
            .drawBehind {
                drawLine(
                    brush = Brush.horizontalGradient(
                        listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.35f),
                            Color(0xFF00FF88).copy(alpha = 0.35f),
                            Color.Transparent
                        )
                    ),
                    start = androidx.compose.ui.geometry.Offset(size.width * 0.15f, 1.dp.toPx()),
                    end = androidx.compose.ui.geometry.Offset(size.width * 0.85f, 1.dp.toPx()),
                    strokeWidth = 1.2.dp.toPx()
                )
            }
            .testTag("interactive_calendar_card")
    ) {
        Column(
            modifier = Modifier.padding(18.dp)
        ) {
            // View Mode Filter Buttons & Navigation row from Screenshot 1
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Navigation < > and Hoy
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF1E293B))
                            .clickable(onClick = onPrevMonth)
                            .testTag("calendar_prev_month_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                            contentDescription = "Anterior",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF1E293B))
                            .clickable(onClick = onNextMonth)
                            .testTag("calendar_next_month_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Siguiente",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .height(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.primary)
                            .clickable(onClick = onTodayClicked)
                            .padding(horizontal = 14.dp)
                            .testTag("calendar_today_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Hoy",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }

                // Pill toggles: Mes, Semana, Día, Año
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("Mes", "Semana", "Día", "Año").forEach { mode ->
                        val isSel = selectedViewMode == mode
                        Box(
                            modifier = Modifier
                                .height(32.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSel) MaterialTheme.colorScheme.primary.copy(alpha = 0.35f) else Color(0xFF1E293B))
                                .border(
                                    width = if (isSel) 1.dp else 0.dp,
                                    color = if (isSel) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable { selectedViewMode = mode }
                                .padding(horizontal = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = mode,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSel) MaterialTheme.colorScheme.primary else Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Month Header: e.g. "Octubre 2026        Vista mensual"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = monthName,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )

                Text(
                    text = "Vista ${selectedViewMode.lowercase()}",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Calendar Table Container with subtle border grid
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(14.dp))
            ) {
                Column {
                    // Weekday headers: L, M, X, J, V, S, D
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF161F33))
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        weekdays.forEach { dayName ->
                            Text(
                                text = dayName,
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Center,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }

                    // Days Grid
                    val chunkedWeeks = daysInGrid.chunked(7)
                    chunkedWeeks.forEachIndexed { index, week ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .then(
                                    if (index > 0) Modifier.border(
                                        width = 0.5.dp,
                                        color = Color(0xFF1E293B).copy(alpha = 0.5f)
                                    ) else Modifier
                                ),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            week.forEach { dayInfo ->
                                val isSelected = dayInfo.dateString == selectedDateString
                                val hasCountdown = countdownDates.contains(dayInfo.dateString)
                                val hasNote = noteDates.contains(dayInfo.dateString)
                                val hasReminder = reminderDates.contains(dayInfo.dateString)

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1.05f)
                                        .padding(1.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CalendarDayCell(
                                        dayInfo = dayInfo,
                                        isSelected = isSelected,
                                        hasCountdown = hasCountdown,
                                        hasNote = hasNote,
                                        hasReminder = hasReminder,
                                        onClick = {
                                            onDateSelected(dayInfo.dateString)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Legend indicators
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LegendIndicator(color = MaterialTheme.colorScheme.primary, label = "Cuentas")
                Spacer(modifier = Modifier.width(16.dp))
                LegendIndicator(color = MaterialTheme.colorScheme.secondary, label = "Notas")
                Spacer(modifier = Modifier.width(16.dp))
                LegendIndicator(color = MaterialTheme.colorScheme.tertiary, label = "Recordatorios")
            }
        }
    }
}

@Composable
private fun LegendIndicator(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            color = Color(0xFF94A3B8)
        )
    }
}

@Composable
private fun CalendarDayCell(
    dayInfo: CalendarDayInfo,
    isSelected: Boolean,
    hasCountdown: Boolean,
    hasNote: Boolean,
    hasReminder: Boolean,
    onClick: () -> Unit
) {
    val bgColor by animateColorAsState(
        targetValue = when {
            isSelected -> MaterialTheme.colorScheme.primary
            dayInfo.isToday -> MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
            else -> Color.Transparent
        },
        label = "day_cell_bg"
    )

    val textColor = when {
        isSelected -> Color.Black
        dayInfo.isToday -> MaterialTheme.colorScheme.primary
        !dayInfo.isCurrentMonth -> Color(0xFF475569)
        else -> Color.White
    }

    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(bgColor)
            .then(
                if (dayInfo.isToday && !isSelected) {
                    Modifier.border(1.5.dp, MaterialTheme.colorScheme.primary, CircleShape)
                } else Modifier
            )
            .clickable(onClick = onClick)
            .testTag("calendar_day_${dayInfo.dateString}"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "${dayInfo.dayOfMonth}",
                fontSize = 13.sp,
                fontWeight = if (isSelected || dayInfo.isToday) FontWeight.Bold else FontWeight.Normal,
                color = textColor
            )

            // Activity Dots
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 1.dp)
            ) {
                if (hasCountdown) {
                    Box(
                        modifier = Modifier
                            .size(3.5.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) Color.Black else MaterialTheme.colorScheme.primary)
                    )
                }
                if (hasNote) {
                    Spacer(modifier = Modifier.width(1.5.dp))
                    Box(
                        modifier = Modifier
                            .size(3.5.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) Color.Black else MaterialTheme.colorScheme.secondary)
                    )
                }
                if (hasReminder) {
                    Spacer(modifier = Modifier.width(1.5.dp))
                    Box(
                        modifier = Modifier
                            .size(3.5.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) Color.Black else MaterialTheme.colorScheme.tertiary)
                    )
                }
            }
        }
    }
}

private fun generateCalendarGrid(year: Int, month: Int): List<CalendarDayInfo> {
    val cal = Calendar.getInstance().apply {
        set(Calendar.YEAR, year)
        set(Calendar.MONTH, month)
        set(Calendar.DAY_OF_MONTH, 1)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }

    val todayCal = Calendar.getInstance()
    val todayYear = todayCal.get(Calendar.YEAR)
    val todayMonth = todayCal.get(Calendar.MONTH)
    val todayDay = todayCal.get(Calendar.DAY_OF_MONTH)

    val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
    val daysBefore = (firstDayOfWeek - Calendar.MONDAY + 7) % 7

    val list = mutableListOf<CalendarDayInfo>()

    val prevMonthCal = (cal.clone() as Calendar).apply {
        add(Calendar.DAY_OF_MONTH, -daysBefore)
    }
    for (i in 0 until daysBefore) {
        val y = prevMonthCal.get(Calendar.YEAR)
        val m = prevMonthCal.get(Calendar.MONTH)
        val d = prevMonthCal.get(Calendar.DAY_OF_MONTH)
        val isToday = (y == todayYear && m == todayMonth && d == todayDay)
        list.add(
            CalendarDayInfo(
                year = y,
                month = m,
                dayOfMonth = d,
                isCurrentMonth = false,
                isToday = isToday,
                dateString = formatDateString(y, m + 1, d)
            )
        )
        prevMonthCal.add(Calendar.DAY_OF_MONTH, 1)
    }

    val maxDaysInCurrentMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    for (day in 1..maxDaysInCurrentMonth) {
        val isToday = (year == todayYear && month == todayMonth && day == todayDay)
        list.add(
            CalendarDayInfo(
                year = year,
                month = month,
                dayOfMonth = day,
                isCurrentMonth = true,
                isToday = isToday,
                dateString = formatDateString(year, month + 1, day)
            )
        )
    }

    val remaining = (7 - (list.size % 7)) % 7
    val nextMonthCal = Calendar.getInstance().apply {
        set(Calendar.YEAR, year)
        set(Calendar.MONTH, month)
        set(Calendar.DAY_OF_MONTH, maxDaysInCurrentMonth)
        add(Calendar.DAY_OF_MONTH, 1)
    }
    for (i in 0 until remaining) {
        val y = nextMonthCal.get(Calendar.YEAR)
        val m = nextMonthCal.get(Calendar.MONTH)
        val d = nextMonthCal.get(Calendar.DAY_OF_MONTH)
        val isToday = (y == todayYear && m == todayMonth && d == todayDay)
        list.add(
            CalendarDayInfo(
                year = y,
                month = m,
                dayOfMonth = d,
                isCurrentMonth = false,
                isToday = isToday,
                dateString = formatDateString(y, m + 1, d)
            )
        )
        nextMonthCal.add(Calendar.DAY_OF_MONTH, 1)
    }

    return list
}

fun formatDateString(year: Int, month1Based: Int, day: Int): String {
    return String.format(Locale.US, "%04d-%02d-%02d", year, month1Based, day)
}
