package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FontStylePreset

data class TimeRemaining(
    val days: Long,
    val hours: Long,
    val minutes: Long,
    val seconds: Long,
    val isPast: Boolean
)

fun calculateTimeRemaining(targetTimestamp: Long, currentTimestamp: Long = System.currentTimeMillis()): TimeRemaining {
    val diff = targetTimestamp - currentTimestamp
    if (diff <= 0) {
        val pastDiff = -diff
        val totalSec = pastDiff / 1000
        val days = totalSec / 86400
        val hours = (totalSec % 86400) / 3600
        val minutes = (totalSec % 3600) / 60
        val seconds = totalSec % 60
        return TimeRemaining(days, hours, minutes, seconds, isPast = true)
    }

    val totalSec = diff / 1000
    val days = totalSec / 86400
    val hours = (totalSec % 86400) / 3600
    val minutes = (totalSec % 3600) / 60
    val seconds = totalSec % 60
    return TimeRemaining(days, hours, minutes, seconds, isPast = false)
}

@Composable
fun TimeTickDisplay(
    timeRemaining: TimeRemaining,
    fontStylePreset: FontStylePreset,
    textColor: Color,
    accentGlowColor: Color,
    is2x2Grid: Boolean = true,
    modifier: Modifier = Modifier
) {
    val fontFamily = when (fontStylePreset) {
        FontStylePreset.DIGITAL -> FontFamily.Monospace
        FontStylePreset.NEON -> FontFamily.SansSerif
        FontStylePreset.CYBERPUNK -> FontFamily.SansSerif
        FontStylePreset.ELEGANT -> FontFamily.Serif
        FontStylePreset.ARCADE -> FontFamily.Monospace
        FontStylePreset.HANDWRITTEN -> FontFamily.Cursive
        FontStylePreset.MONOSPACE -> FontFamily.Monospace
        FontStylePreset.BOLD_MINIMAL -> FontFamily.Default
    }

    val fontStyle = if (fontStylePreset == FontStylePreset.HANDWRITTEN) FontStyle.Italic else FontStyle.Normal
    val fontWeight = when (fontStylePreset) {
        FontStylePreset.BOLD_MINIMAL, FontStylePreset.CYBERPUNK, FontStylePreset.ARCADE -> FontWeight.Black
        FontStylePreset.ELEGANT -> FontWeight.SemiBold
        else -> FontWeight.Bold
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (timeRemaining.isPast) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFE53935).copy(alpha = 0.2f))
                    .border(1.dp, Color(0xFFE53935), RoundedCornerShape(12.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "¡El evento ya ha comenzado! (Tiempo transcurrido)",
                    color = Color(0xFFFF8A80),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        if (is2x2Grid) {
            // 2x2 Grid matching user's prototype screenshot 2
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    TimeUnitCard(
                        value = timeRemaining.days,
                        label = "DÍAS",
                        textColor = textColor,
                        glowColor = accentGlowColor,
                        fontFamily = fontFamily,
                        fontStyle = fontStyle,
                        fontWeight = fontWeight,
                        modifier = Modifier.weight(1f)
                    )
                    TimeUnitCard(
                        value = timeRemaining.hours,
                        label = "HORAS",
                        textColor = textColor,
                        glowColor = accentGlowColor,
                        fontFamily = fontFamily,
                        fontStyle = fontStyle,
                        fontWeight = fontWeight,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    TimeUnitCard(
                        value = timeRemaining.minutes,
                        label = "MINUTOS",
                        textColor = textColor,
                        glowColor = accentGlowColor,
                        fontFamily = fontFamily,
                        fontStyle = fontStyle,
                        fontWeight = fontWeight,
                        modifier = Modifier.weight(1f)
                    )
                    TimeUnitCard(
                        value = timeRemaining.seconds,
                        label = "SEGUNDOS",
                        textColor = textColor,
                        glowColor = accentGlowColor,
                        fontFamily = fontFamily,
                        fontStyle = fontStyle,
                        fontWeight = fontWeight,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        } else {
            // Horizontal row (for mini previews)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TimeUnitCard(
                    value = timeRemaining.days,
                    label = "DÍAS",
                    textColor = textColor,
                    glowColor = accentGlowColor,
                    fontFamily = fontFamily,
                    fontStyle = fontStyle,
                    fontWeight = fontWeight,
                    modifier = Modifier.weight(1f)
                )
                TimeUnitCard(
                    value = timeRemaining.hours,
                    label = "HORAS",
                    textColor = textColor,
                    glowColor = accentGlowColor,
                    fontFamily = fontFamily,
                    fontStyle = fontStyle,
                    fontWeight = fontWeight,
                    modifier = Modifier.weight(1f)
                )
                TimeUnitCard(
                    value = timeRemaining.minutes,
                    label = "MIN",
                    textColor = textColor,
                    glowColor = accentGlowColor,
                    fontFamily = fontFamily,
                    fontStyle = fontStyle,
                    fontWeight = fontWeight,
                    modifier = Modifier.weight(1f)
                )
                TimeUnitCard(
                    value = timeRemaining.seconds,
                    label = "SEG",
                    textColor = textColor,
                    glowColor = accentGlowColor,
                    fontFamily = fontFamily,
                    fontStyle = fontStyle,
                    fontWeight = fontWeight,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun TimeUnitCard(
    value: Long,
    label: String,
    textColor: Color,
    glowColor: Color,
    fontFamily: FontFamily,
    fontStyle: FontStyle,
    fontWeight: FontWeight,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(22.dp)

    Box(
        modifier = modifier
            .shadow(
                elevation = 10.dp,
                shape = shape,
                spotColor = glowColor.copy(alpha = 0.5f),
                ambientColor = Color.Black
            )
            .clip(shape)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F1E1E).copy(alpha = 0.85f),
                        Color(0xFF071112).copy(alpha = 0.95f)
                    )
                )
            )
            .border(
                width = 1.5.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        glowColor.copy(alpha = 0.85f),
                        glowColor.copy(alpha = 0.2f)
                    )
                ),
                shape = shape
            )
            .drawBehind {
                drawLine(
                    brush = Brush.horizontalGradient(
                        listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.35f),
                            glowColor.copy(alpha = 0.45f),
                            Color.Transparent
                        )
                    ),
                    start = androidx.compose.ui.geometry.Offset(size.width * 0.15f, 1.dp.toPx()),
                    end = androidx.compose.ui.geometry.Offset(size.width * 0.85f, 1.dp.toPx()),
                    strokeWidth = 1.2.dp.toPx()
                )
            }
            .padding(vertical = 18.dp, horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            val formattedValue = String.format("%02d", value)

            AnimatedContent(
                targetState = formattedValue,
                transitionSpec = {
                    slideInVertically { height -> height } togetherWith
                            slideOutVertically { height -> -height }
                },
                label = "unit_card_value"
            ) { targetText ->
                Text(
                    text = targetText,
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = fontFamily,
                    fontStyle = fontStyle,
                    color = textColor,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF94A3B8),
                letterSpacing = 2.sp
            )
        }
    }
}
