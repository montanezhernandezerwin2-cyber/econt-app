package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Default legacy colors
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// ChronoGlow Theme Presets
enum class AppThemePalette(
    val title: String,
    val primary: Color,
    val secondary: Color,
    val tertiary: Color,
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color
) {
    CYBER_NEON(
        title = "Cyber Neón",
        primary = Color(0xFF00E5FF),
        secondary = Color(0xFFFF007F),
        tertiary = Color(0xFF76FF03),
        background = Color(0xFF0B0F19),
        surface = Color(0xFF131A29),
        surfaceVariant = Color(0xFF1E283D)
    ),
    EMERALD_MINT(
        title = "Esmeralda Menta",
        primary = Color(0xFF00E676),
        secondary = Color(0xFF00B0FF),
        tertiary = Color(0xFFAEEA00),
        background = Color(0xFF061A12),
        surface = Color(0xFF0D281E),
        surfaceVariant = Color(0xFF163C2E)
    ),
    SUNSET_CRIMSON(
        title = "Atardecer Carmesí",
        primary = Color(0xFFFF6D00),
        secondary = Color(0xFFFF1744),
        tertiary = Color(0xFFFFD600),
        background = Color(0xFF1A0B10),
        surface = Color(0xFF28131B),
        surfaceVariant = Color(0xFF3B1D28)
    ),
    ROYAL_GOLD(
        title = "Oro Real",
        primary = Color(0xFFFFD700),
        secondary = Color(0xFFFFAB00),
        tertiary = Color(0xFFFFE082),
        background = Color(0xFF101014),
        surface = Color(0xFF1B1B22),
        surfaceVariant = Color(0xFF282833)
    ),
    COSMIC_VIOLET(
        title = "Violeta Cósmico",
        primary = Color(0xFFB388FF),
        secondary = Color(0xFF7C4DFF),
        tertiary = Color(0xFFFF4081),
        background = Color(0xFF0E0720),
        surface = Color(0xFF180F33),
        surfaceVariant = Color(0xFF271A4E)
    ),
    OCEAN_BLUE(
        title = "Océano Profundo",
        primary = Color(0xFF00B0FF),
        secondary = Color(0xFF2979FF),
        tertiary = Color(0xFF00E5FF),
        background = Color(0xFF071324),
        surface = Color(0xFF0E223D),
        surfaceVariant = Color(0xFF17355C)
    ),
    AMOLED_STEEL(
        title = "Amoled Puro",
        primary = Color(0xFFE2E8F0),
        secondary = Color(0xFF38BDF8),
        tertiary = Color(0xFFA855F7),
        background = Color(0xFF000000),
        surface = Color(0xFF111111),
        surfaceVariant = Color(0xFF222222)
    )
}
