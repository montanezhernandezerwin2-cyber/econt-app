package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.BackgroundPreset
import com.example.data.model.CalendarNoteEntity
import com.example.data.model.CalendarReminderEntity
import com.example.data.model.CountdownEntity
import com.example.data.model.CustomCategoryEntity
import com.example.data.model.FontStylePreset
import com.example.data.model.SoundPreset
import com.example.data.model.VisualEffectType
import com.example.ui.theme.AppThemePalette
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

sealed interface AppScreen {
    data object Splash : AppScreen
    data object CalendarHome : AppScreen
    data class Studio(val countdownToEdit: CountdownEntity? = null, val initialDateString: String? = null) : AppScreen
    data class Viewer(val countdown: CountdownEntity) : AppScreen
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val countdownDao = db.countdownDao()
    private val calendarDao = db.calendarDao()
    private val categoryDao = db.categoryDao()

    val countdowns: StateFlow<List<CountdownEntity>> = countdownDao.getAllCountdowns()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notes: StateFlow<List<CalendarNoteEntity>> = calendarDao.getAllNotes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reminders: StateFlow<List<CalendarReminderEntity>> = calendarDao.getAllReminders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customCategories: StateFlow<List<CustomCategoryEntity>> = categoryDao.getAllCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentPalette = MutableStateFlow(AppThemePalette.CYBER_NEON)
    val currentPalette: StateFlow<AppThemePalette> = _currentPalette.asStateFlow()

    private val _currentScreen = MutableStateFlow<AppScreen>(AppScreen.Splash)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    init {
        seedInitialSampleData()
    }

    private fun seedInitialSampleData() {
        viewModelScope.launch {
            // Seed default categories
            val defaultCats = listOf(
                "🎬 Cine / Película",
                "🎵 Concierto",
                "🎂 Cumpleaños",
                "✈️ Viaje",
                "🎉 Fiesta",
                "🎮 Lanzamiento Gamer",
                "💍 Boda",
                "🎓 Graduación",
                "⚽ Partido / Deporte",
                "🚀 Meta Personal"
            )
            for (cat in defaultCats) {
                categoryDao.insertCategory(CustomCategoryEntity(cat))
            }

            // Seed sample countdown if empty
            val existing = countdownDao.getCountdownById(1)
            if (existing == null) {
                val cal = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_MONTH, 3)
                    set(Calendar.HOUR_OF_DAY, 21)
                    set(Calendar.MINUTE, 30)
                    set(Calendar.SECOND, 0)
                }

                val sampleCountdown = CountdownEntity(
                    id = 1,
                    title = "AVATAR: FUEGO Y CENIZAS",
                    antetitulo = "ESTRENO EXCLUSIVO EN CINES",
                    lugar = "Cinépolis Sala IMAX 3D",
                    targetTimestamp = cal.timeInMillis,
                    category = "🎬 Cine / Película",
                    fontStyle = FontStylePreset.CYBERPUNK.name,
                    textColorHex = "#00FFFF",
                    effectType = VisualEffectType.NEON_PULSE.name,
                    effectColorHex = "#00FF66",
                    effectSpeed = 1.0f,
                    effectIntensity = 1.2f,
                    backgroundPreset = BackgroundPreset.CINEMA_NEON.name,
                    soundPreset = SoundPreset.CINEMA_BOOM.name,
                    isSoundEnabled = true,
                    isVibrateEnabled = true,
                    extraSubtitle = "Función especial de medianoche con amigos",
                    extraMessage = "Comprar palomitas gigantes y combos antes de entrar.",
                    extraQuote = "Ver el mundo con nuevos ojos."
                )
                countdownDao.insertCountdown(sampleCountdown)

                // Seed sample note and reminder
                val todayCal = Calendar.getInstance()
                val todayStr = String.format(
                    java.util.Locale.US,
                    "%04d-%02d-%02d",
                    todayCal.get(Calendar.YEAR),
                    todayCal.get(Calendar.MONTH) + 1,
                    todayCal.get(Calendar.DAY_OF_MONTH)
                )

                calendarDao.insertNote(
                    CalendarNoteEntity(
                        dateString = todayStr,
                        title = "Boletos de Cine",
                        content = "Verificar asientos en fila central para la mejor vista de la pantalla IMAX.",
                        colorHex = "#10B981"
                    )
                )

                calendarDao.insertReminder(
                    CalendarReminderEntity(
                        dateString = todayStr,
                        timeString = "19:00",
                        title = "Salir rumbo al cine",
                        isCompleted = false,
                        priority = "Alta"
                    )
                )
            }
        }
    }

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun setPalette(palette: AppThemePalette) {
        _currentPalette.value = palette
    }

    fun addCategory(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            categoryDao.insertCategory(CustomCategoryEntity(name.trim()))
        }
    }

    fun deleteCategory(category: CustomCategoryEntity) {
        viewModelScope.launch {
            categoryDao.deleteCategory(category)
        }
    }

    fun saveCountdown(countdown: CountdownEntity, stayInViewer: Boolean = true) {
        viewModelScope.launch {
            val finalId = if (countdown.id == 0L) {
                countdownDao.insertCountdown(countdown)
            } else {
                countdownDao.updateCountdown(countdown)
                countdown.id
            }
            val saved = countdown.copy(id = finalId)
            if (stayInViewer) {
                _currentScreen.value = AppScreen.Viewer(saved)
            } else {
                _currentScreen.value = AppScreen.CalendarHome
            }
        }
    }

    fun deleteCountdown(countdown: CountdownEntity) {
        viewModelScope.launch {
            countdownDao.deleteCountdown(countdown)
            if (_currentScreen.value is AppScreen.Viewer) {
                _currentScreen.value = AppScreen.CalendarHome
            }
        }
    }

    fun saveNote(note: CalendarNoteEntity) {
        viewModelScope.launch {
            if (note.id == 0L) {
                calendarDao.insertNote(note)
            } else {
                calendarDao.updateNote(note)
            }
        }
    }

    fun deleteNote(note: CalendarNoteEntity) {
        viewModelScope.launch {
            calendarDao.deleteNote(note)
        }
    }

    fun saveReminder(reminder: CalendarReminderEntity) {
        viewModelScope.launch {
            if (reminder.id == 0L) {
                calendarDao.insertReminder(reminder)
            } else {
                calendarDao.updateReminder(reminder)
            }
        }
    }

    fun toggleReminder(reminder: CalendarReminderEntity) {
        viewModelScope.launch {
            calendarDao.updateReminder(reminder.copy(isCompleted = !reminder.isCompleted))
        }
    }

    fun deleteReminder(reminder: CalendarReminderEntity) {
        viewModelScope.launch {
            calendarDao.deleteReminder(reminder)
        }
    }
}
