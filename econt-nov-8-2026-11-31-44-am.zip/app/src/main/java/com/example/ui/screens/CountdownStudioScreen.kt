package com.example.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.audio.CountdownSoundPlayer
import com.example.data.model.BackgroundPreset
import com.example.data.model.CountdownEntity
import com.example.data.model.CustomCategoryEntity
import com.example.data.model.FontStylePreset
import com.example.data.model.SoundPreset
import com.example.data.model.VisualEffectType
import com.example.effects.CountdownEffectOverlay
import com.example.ui.components.EffectSelectorDialog
import com.example.ui.components.TimeTickDisplay
import com.example.ui.components.WebPreviewDialog
import com.example.ui.components.calculateTimeRemaining
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CountdownStudioScreen(
    initialCountdown: CountdownEntity? = null,
    initialDateString: String? = null,
    availableCategories: List<CustomCategoryEntity> = emptyList(),
    onAddCustomCategory: (String) -> Unit = {},
    onSave: (CountdownEntity) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val soundPlayer = remember { CountdownSoundPlayer(context) }

    DisposableEffect(Unit) {
        onDispose {
            soundPlayer.stopAll()
        }
    }

    // Calendar target initialization
    val targetCal = remember {
        Calendar.getInstance().apply {
            if (initialCountdown != null) {
                timeInMillis = initialCountdown.targetTimestamp
            } else if (!initialDateString.isNullOrBlank()) {
                try {
                    val parts = initialDateString.split("-")
                    set(Calendar.YEAR, parts[0].toInt())
                    set(Calendar.MONTH, parts[1].toInt() - 1)
                    set(Calendar.DAY_OF_MONTH, parts[2].toInt())
                    set(Calendar.HOUR_OF_DAY, 21)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                } catch (_: Exception) {
                    add(Calendar.DAY_OF_MONTH, 3)
                }
            } else {
                add(Calendar.DAY_OF_MONTH, 3)
                set(Calendar.HOUR_OF_DAY, 21)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
            }
        }
    }

    // Explicit user requested fields: Título, Antetítulo, Lugar, Subtítulo, etc.
    var title by remember { mutableStateOf(initialCountdown?.title ?: "Ir al Cine: Estreno Especial") }
    var antetitulo by remember { mutableStateOf(initialCountdown?.antetitulo ?: "FUNCIÓN EXCLUSIVA") }
    var lugar by remember { mutableStateOf(initialCountdown?.lugar ?: "Cinépolis Sala IMAX") }
    var extraSubtitle by remember { mutableStateOf(initialCountdown?.extraSubtitle ?: "Noche de estreno con amigos") }
    var extraMessage by remember { mutableStateOf(initialCountdown?.extraMessage ?: "Comprar palomitas y combos antes de entrar.") }
    var extraQuote by remember { mutableStateOf(initialCountdown?.extraQuote ?: "Una experiencia cinematográfica inolvidable.") }

    var category by remember { mutableStateOf(initialCountdown?.category ?: "🎬 Cine / Película") }
    var targetTimestamp by remember { mutableLongStateOf(targetCal.timeInMillis) }

    // Media & Photos with URL or gallery
    var imageUrl by remember { mutableStateOf(initialCountdown?.imageUrl ?: "") }
    var customImageUriString by remember { mutableStateOf(initialCountdown?.customImageUri) }
    var selectedBackground by remember {
        mutableStateOf(
            try { BackgroundPreset.valueOf(initialCountdown?.backgroundPreset ?: "") }
            catch (_: Exception) { BackgroundPreset.CINEMA_NEON }
        )
    }

    // Styles & Effects
    var selectedFont by remember {
        mutableStateOf(
            try { FontStylePreset.valueOf(initialCountdown?.fontStyle ?: "") }
            catch (_: Exception) { FontStylePreset.CYBERPUNK }
        )
    }
    var textColorHex by remember { mutableStateOf(initialCountdown?.textColorHex ?: "#00FFFF") }
    var selectedEffect by remember {
        mutableStateOf(
            try { VisualEffectType.valueOf(initialCountdown?.effectType ?: "") }
            catch (_: Exception) { VisualEffectType.NEON_PULSE }
        )
    }
    var effectColorHex by remember { mutableStateOf(initialCountdown?.effectColorHex ?: "#00FF66") }
    var effectSpeed by remember { mutableFloatStateOf(initialCountdown?.effectSpeed ?: 1.0f) }
    var effectIntensity by remember { mutableFloatStateOf(initialCountdown?.effectIntensity ?: 1.0f) }

    // Sounds
    var selectedSound by remember {
        mutableStateOf(
            try { SoundPreset.valueOf(initialCountdown?.soundPreset ?: "") }
            catch (_: Exception) { SoundPreset.CINEMA_BOOM }
        )
    }
    var isSoundEnabled by remember { mutableStateOf(initialCountdown?.isSoundEnabled ?: true) }
    var isVibrateEnabled by remember { mutableStateOf(initialCountdown?.isVibrateEnabled ?: true) }

    // Modals
    var showEffectDialog by remember { mutableStateOf(false) }
    var showWebPreviewDialog by remember { mutableStateOf(false) }
    var showAddCategoryDialog by remember { mutableStateOf(false) }
    var newCategoryText by remember { mutableStateOf("") }

    // Photo Picker
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            customImageUriString = uri.toString()
            imageUrl = ""
            selectedBackground = BackgroundPreset.CUSTOM_IMAGE
        }
    }

    // Live ticker
    var currentMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(250)
            currentMillis = System.currentTimeMillis()
        }
    }

    val remaining = remember(targetTimestamp, currentMillis) {
        calculateTimeRemaining(targetTimestamp, currentMillis)
    }

    val parsedTextColor = remember(textColorHex) {
        try { Color(android.graphics.Color.parseColor(textColorHex)) } catch (_: Exception) { Color.Cyan }
    }
    val parsedEffectColor = remember(effectColorHex) {
        try { Color(android.graphics.Color.parseColor(effectColorHex)) } catch (_: Exception) { Color(0xFF00FF66) }
    }

    val dateFormat = remember { SimpleDateFormat("dd 'de' MMMM, yyyy", Locale("es", "ES")) }
    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.US) }

    val formattedDate = remember(targetTimestamp) { dateFormat.format(targetTimestamp) }
    val formattedTime = remember(targetTimestamp) { timeFormat.format(targetTimestamp) }

    val currentEntity = remember(
        title, antetitulo, lugar, extraSubtitle, extraMessage, extraQuote,
        targetTimestamp, category, selectedFont, textColorHex,
        selectedEffect, effectColorHex, effectSpeed, effectIntensity,
        selectedBackground, customImageUriString, imageUrl,
        selectedSound, isSoundEnabled, isVibrateEnabled
    ) {
        CountdownEntity(
            id = initialCountdown?.id ?: 0,
            title = title.ifBlank { "Cuenta Regresiva" },
            antetitulo = antetitulo,
            lugar = lugar,
            targetTimestamp = targetTimestamp,
            category = category,
            fontStyle = selectedFont.name,
            textColorHex = textColorHex,
            effectType = selectedEffect.name,
            effectColorHex = effectColorHex,
            effectSpeed = effectSpeed,
            effectIntensity = effectIntensity,
            backgroundPreset = selectedBackground.name,
            customImageUri = customImageUriString,
            imageUrl = imageUrl,
            soundPreset = selectedSound.name,
            isSoundEnabled = isSoundEnabled,
            isVibrateEnabled = isVibrateEnabled,
            extraSubtitle = extraSubtitle,
            extraMessage = extraMessage,
            extraQuote = extraQuote
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (initialCountdown == null) "Crear Cuenta Regresiva" else "Editar Cuenta",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Regresar")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showWebPreviewDialog = true },
                        modifier = Modifier.testTag("preview_web_action_button")
                    ) {
                        Icon(
                            Icons.Default.Language,
                            contentDescription = "Sitio Web",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = {
                            if (title.isBlank()) {
                                Toast.makeText(context, "Por favor escribe un título", Toast.LENGTH_SHORT).show()
                            } else {
                                onSave(currentEntity)
                            }
                        },
                        modifier = Modifier.testTag("save_countdown_top_button")
                    ) {
                        Icon(
                            Icons.Default.Save,
                            contentDescription = "Guardar",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Interactive Preview Canvas
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF090E17))
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Custom photo or web image
                    if (imageUrl.isNotBlank()) {
                        AsyncImage(
                            model = imageUrl,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)))
                    } else if (selectedBackground == BackgroundPreset.CUSTOM_IMAGE && customImageUriString != null) {
                        AsyncImage(
                            model = customImageUriString,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)))
                    }

                    // Visual Effect
                    CountdownEffectOverlay(
                        effectType = selectedEffect,
                        effectColor = parsedEffectColor,
                        speed = effectSpeed,
                        intensity = effectIntensity
                    )

                    // Card Overlays
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        if (antetitulo.isNotBlank()) {
                            Text(
                                text = antetitulo.uppercase(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = parsedEffectColor,
                                letterSpacing = 1.5.sp
                            )
                        }

                        Text(
                            text = title.ifBlank { "Título del Evento" },
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = parsedTextColor
                        )

                        if (lugar.isNotBlank()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = lugar,
                                    fontSize = 11.sp,
                                    color = Color(0xFF38BDF8),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        TimeTickDisplay(
                            timeRemaining = remaining,
                            fontStylePreset = selectedFont,
                            textColor = parsedTextColor,
                            accentGlowColor = parsedEffectColor
                        )
                    }
                }
            }

            // Quick Plantillas / Atajos (Easy 1-tap setup)
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Plantillas Rápidas (Configuración en 1 Toque)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        QuickTemplateChip("🎬 Cine / Película") {
                            title = "Estreno en Cines: Película"
                            antetitulo = "GRAN FUNCIÓN"
                            lugar = "Cinépolis Sala IMAX"
                            category = "🎬 Cine / Película"
                            selectedSound = SoundPreset.CINEMA_BOOM
                            selectedEffect = VisualEffectType.NEON_PULSE
                            selectedBackground = BackgroundPreset.CINEMA_NEON
                            imageUrl = "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=800&q=80"
                        }
                        QuickTemplateChip("🎵 Concierto") {
                            title = "Concierto en Vivo"
                            antetitulo = "GIRA MUNDIAL"
                            lugar = "Estadio Principal"
                            category = "🎵 Concierto"
                            selectedSound = SoundPreset.SYNTH_PLUCK
                            selectedEffect = VisualEffectType.DISCO_STROBE
                            imageUrl = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=800&q=80"
                        }
                        QuickTemplateChip("🎂 Cumpleaños") {
                            title = "Mi Gran Cumpleaños"
                            antetitulo = "¡DÍA ESPECIAL!"
                            lugar = "Casa / Salón de Fiestas"
                            category = "🎂 Cumpleaños"
                            selectedSound = SoundPreset.BELL_DING
                            selectedEffect = VisualEffectType.CONFETTI_SHOWER
                            imageUrl = "https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=800&q=80"
                        }
                        QuickTemplateChip("✈️ Viaje") {
                            title = "Vuelo y Vacaciones"
                            antetitulo = "DESTINO PARADISÍACO"
                            lugar = "Aeropuerto Internacional"
                            category = "✈️ Viaje"
                            selectedSound = SoundPreset.RADAR_PING
                            selectedEffect = VisualEffectType.AURORA_BOREALIS
                            imageUrl = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80"
                        }
                        QuickTemplateChip("🎮 Lanzamiento Gamer") {
                            title = "Lanzamiento del Videojuego"
                            antetitulo = "ESTRENO MUNDIAL GAMER"
                            lugar = "Online / Consola & PC"
                            category = "🎮 Lanzamiento Gamer"
                            selectedSound = SoundPreset.SCI_FI_BLASTER
                            selectedEffect = VisualEffectType.CYBER_GLITCH
                            imageUrl = "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=800&q=80"
                        }
                    }
                }
            }

            // Categoría con opción de crear personalizadas
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Categoría del Evento:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        OutlinedButton(
                            onClick = { showAddCategoryDialog = true },
                            modifier = Modifier.height(34.dp).testTag("add_custom_category_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("+ Nueva Categoría", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val allCats = (availableCategories.map { it.name } + listOf(
                        "🎬 Cine / Película", "🎵 Concierto", "🎂 Cumpleaños", "✈️ Viaje", "🎉 Fiesta", "🎮 Gamer", "⚽ Deportes"
                    )).distinct()

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        allCats.forEach { cat ->
                            val isSel = category == cat
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { category = cat }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = cat,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSel) Color.Black else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            // Campos de Título, Antetítulo, Lugar y Textos
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Títulos, Lugar y Textos",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )

                    OutlinedTextField(
                        value = antetitulo,
                        onValueChange = { antetitulo = it },
                        label = { Text("Antetítulo / Prefijo") },
                        placeholder = { Text("Ej: ESTRENO EXCLUSIVO, GRAN NOCHE, DÍA CERO...") },
                        modifier = Modifier.fillMaxWidth().testTag("countdown_antetitulo_input"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Título") },
                        placeholder = { Text("Ej: Avatar: Fuego y Cenizas, Mi Boda, Vacaciones...") },
                        modifier = Modifier.fillMaxWidth().testTag("countdown_title_input"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = lugar,
                        onValueChange = { lugar = it },
                        label = { Text("Lugar / Ubicación") },
                        placeholder = { Text("Ej: Cinépolis Sala IMAX, Auditorio Nacional, Mi Casa...") },
                        modifier = Modifier.fillMaxWidth().testTag("countdown_lugar_input"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = extraSubtitle,
                        onValueChange = { extraSubtitle = it },
                        label = { Text("Subtítulo") },
                        placeholder = { Text("Ej: Función de las 21:30 hs con amigos...") },
                        modifier = Modifier.fillMaxWidth().testTag("countdown_subtitle_input"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = extraMessage,
                        onValueChange = { extraMessage = it },
                        label = { Text("Notas adicionales") },
                        placeholder = { Text("Ej: Comprar palomitas gigantes y llegar 15 minutos antes...") },
                        modifier = Modifier.fillMaxWidth().testTag("countdown_message_input"),
                        maxLines = 3
                    )

                    OutlinedTextField(
                        value = extraQuote,
                        onValueChange = { extraQuote = it },
                        label = { Text("Frase / Cita") },
                        placeholder = { Text("Ej: El cine es la fábrica de los sueños...") },
                        modifier = Modifier.fillMaxWidth().testTag("countdown_quote_input"),
                        singleLine = true
                    )
                }
            }

            // Fecha y Hora con atajos rápidos (+1 día, +1 semana, horas comunes)
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Fecha y Hora Exacta",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val cal = Calendar.getInstance().apply { timeInMillis = targetTimestamp }
                                DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        cal.set(Calendar.YEAR, year)
                                        cal.set(Calendar.MONTH, month)
                                        cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                                        targetTimestamp = cal.timeInMillis
                                    },
                                    cal.get(Calendar.YEAR),
                                    cal.get(Calendar.MONTH),
                                    cal.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            },
                            modifier = Modifier.weight(1f).testTag("select_date_button"),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = formattedDate, fontSize = 12.sp, maxLines = 1)
                        }

                        OutlinedButton(
                            onClick = {
                                val cal = Calendar.getInstance().apply { timeInMillis = targetTimestamp }
                                TimePickerDialog(
                                    context,
                                    { _, hourOfDay, minute ->
                                        cal.set(Calendar.HOUR_OF_DAY, hourOfDay)
                                        cal.set(Calendar.MINUTE, minute)
                                        cal.set(Calendar.SECOND, 0)
                                        targetTimestamp = cal.timeInMillis
                                    },
                                    cal.get(Calendar.HOUR_OF_DAY),
                                    cal.get(Calendar.MINUTE),
                                    true
                                ).show()
                            },
                            modifier = Modifier.weight(1f).testTag("select_time_button"),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.AccessTime, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "$formattedTime hs", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Botones de ajuste rápido
                    Text("Atajos de Fecha Rápidos:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        QuickOffsetButton("+1 Día") {
                            targetTimestamp += 86400000L
                        }
                        QuickOffsetButton("+3 Días") {
                            targetTimestamp += 3 * 86400000L
                        }
                        QuickOffsetButton("+1 Semana") {
                            targetTimestamp += 7 * 86400000L
                        }
                        QuickOffsetButton("+1 Mes") {
                            val c = Calendar.getInstance().apply { timeInMillis = targetTimestamp }
                            c.add(Calendar.MONTH, 1)
                            targetTimestamp = c.timeInMillis
                        }
                        QuickOffsetButton("A las 20:00 hs") {
                            val c = Calendar.getInstance().apply { timeInMillis = targetTimestamp }
                            c.set(Calendar.HOUR_OF_DAY, 20)
                            c.set(Calendar.MINUTE, 0)
                            c.set(Calendar.SECOND, 0)
                            targetTimestamp = c.timeInMillis
                        }
                    }
                }
            }

            // Fotos con Enlaces de Internet y Galería
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Link, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Foto o Fondo con Enlace Web",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Pega cualquier enlace (URL) de una imagen de internet o usa una de tu galería:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = imageUrl,
                            onValueChange = { imageUrl = it },
                            label = { Text("Enlace / URL de la Imagen") },
                            placeholder = { Text("https://ejemplo.com/poster.jpg") },
                            trailingIcon = {
                                if (imageUrl.isNotBlank()) {
                                    IconButton(onClick = { imageUrl = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Limpiar")
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f).testTag("image_url_input"),
                            singleLine = true
                        )

                        Button(
                            onClick = {
                                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                                val clip = clipboard?.primaryClip
                                var extracted = ""
                                if (clip != null && clip.itemCount > 0) {
                                    val item = clip.getItemAt(0)
                                    val txt = item.text?.toString() ?: ""
                                    val uri = item.uri?.toString() ?: ""
                                    extracted = if (txt.isNotBlank()) txt else uri
                                }
                                // Sanitize URL
                                var clean = extracted.trim().removeSurrounding("\"", "\"").removeSurrounding("'", "'")
                                val mdMatch = Regex("\\((https?://[^)]+)\\)").find(clean)
                                if (mdMatch != null) {
                                    clean = mdMatch.groupValues[1]
                                }
                                if (clean.isNotBlank()) {
                                    imageUrl = clean
                                    Toast.makeText(context, "¡Enlace de imagen pegado con éxito!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "El portapapeles no tiene ningún enlace copiado", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.height(56.dp).testTag("paste_image_url_button"),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("Pegar", fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier.weight(1f).testTag("pick_photo_studio_button"),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Galería", fontSize = 12.sp)
                        }

                        if (imageUrl.isNotBlank()) {
                            OutlinedButton(
                                onClick = { imageUrl = "" },
                                modifier = Modifier.weight(0.7f),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text("Quitar Foto", fontSize = 11.sp, color = Color(0xFFEF4444))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Fondos 4K de Alta Definición (1 Toque):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        QuickWallpaperChip("🎬 Cinema Doomsday") {
                            imageUrl = "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1200&q=80"
                        }
                        QuickWallpaperChip("🌌 Galaxia 4K") {
                            imageUrl = "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=1200&q=80"
                        }
                        QuickWallpaperChip("⚡ Cyberpunk") {
                            imageUrl = "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1200&q=80"
                        }
                        QuickWallpaperChip("🎂 Fiesta Neón") {
                            imageUrl = "https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=1200&q=80"
                        }
                        QuickWallpaperChip("🏖️ Sunset") {
                            imageUrl = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80"
                        }
                    }
                }
            }

            // Catálogo de Sonidos Ampliado con botón de prueba rápida
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Sonido de Segundos (15 Estilos)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Switch(
                            checked = isSoundEnabled,
                            onCheckedChange = { isSoundEnabled = it },
                            modifier = Modifier.testTag("sound_enabled_switch")
                        )
                    }

                    if (isSoundEnabled) {
                        Spacer(modifier = Modifier.height(10.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            SoundPreset.values().forEach { sound ->
                                val isSel = selectedSound == sound
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                        .clickable {
                                            selectedSound = sound
                                            soundPlayer.playTick(sound, isVibrateEnabled)
                                        }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = sound.displayName,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSel) Color.Black else MaterialTheme.colorScheme.onSurface
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = "Probar",
                                            tint = if (isSel) Color.Black else MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Vibration, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Vibración háptica por segundo", fontSize = 13.sp)
                        }
                        Switch(
                            checked = isVibrateEnabled,
                            onCheckedChange = { isVibrateEnabled = it },
                            modifier = Modifier.testTag("vibrate_enabled_switch")
                        )
                    }
                }
            }

            // Efectos Visuales
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Efecto Visual (20 Únicos)",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = selectedEffect.displayName,
                                fontSize = 12.sp,
                                color = parsedEffectColor
                            )
                        }

                        Button(
                            onClick = { showEffectDialog = true },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.testTag("open_effects_dialog_button")
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Ajustar 20", fontSize = 12.sp)
                        }
                    }
                }
            }

            // Botones de Acción
            Button(
                onClick = {
                    if (title.isBlank()) {
                        Toast.makeText(context, "Por favor escribe un título", Toast.LENGTH_SHORT).show()
                    } else {
                        onSave(currentEntity)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("save_countdown_bottom_button"),
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Guardar Cuenta Regresiva",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            OutlinedButton(
                onClick = { showWebPreviewDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("view_as_website_button"),
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(Icons.Default.Language, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Crear y Abrir Sitio Web",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showAddCategoryDialog) {
        Dialog(onDismissRequest = { showAddCategoryDialog = false }) {
            Surface(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)),
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Nueva Categoría Personalizada", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = newCategoryText,
                        onValueChange = { newCategoryText = it },
                        label = { Text("Nombre de la Categoría") },
                        placeholder = { Text("Ej: Cine con amigos, Estreno Marvel...") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(onClick = { showAddCategoryDialog = false }) {
                            Text("Cancelar")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (newCategoryText.isNotBlank()) {
                                    onAddCustomCategory(newCategoryText.trim())
                                    category = newCategoryText.trim()
                                    newCategoryText = ""
                                    showAddCategoryDialog = false
                                }
                            }
                        ) {
                            Text("Agregar")
                        }
                    }
                }
            }
        }
    }

    if (showEffectDialog) {
        EffectSelectorDialog(
            selectedEffect = selectedEffect,
            effectColorHex = effectColorHex,
            currentSpeed = effectSpeed,
            currentIntensity = effectIntensity,
            onEffectSelected = { newEffect, newColor, newSpeed, newIntensity ->
                selectedEffect = newEffect
                effectColorHex = newColor
                effectSpeed = newSpeed
                effectIntensity = newIntensity
            },
            onDismiss = { showEffectDialog = false }
        )
    }

    if (showWebPreviewDialog) {
        WebPreviewDialog(
            countdown = currentEntity,
            onDismiss = { showWebPreviewDialog = false }
        )
    }
}

@Composable
private fun QuickTemplateChip(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text = label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun QuickOffsetButton(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(text = label, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun QuickWallpaperChip(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF1E293B))
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(text = label, fontSize = 11.sp, color = Color(0xFF00FF88), fontWeight = FontWeight.SemiBold)
    }
}
