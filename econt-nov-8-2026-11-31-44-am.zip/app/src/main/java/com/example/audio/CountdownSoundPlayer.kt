package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.example.data.model.SoundPreset
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Ultra-smooth, high-fidelity sound player for countdown ticks.
 * Fixed audio synthesis (no harsh clicks/glitches, smooth attack/decay envelopes),
 * thread-safe track tracking, and instant stopAll() on screen exit.
 */
class CountdownSoundPlayer(private val context: Context) {

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private val sampleRate = 44100
    private var scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val activeTracks = ConcurrentLinkedQueue<AudioTrack>()
    private val activeJobs = ConcurrentLinkedQueue<Job>()

    @Volatile
    private var isMuted = false

    fun playTick(preset: SoundPreset, isVibrateEnabled: Boolean = true) {
        if (isMuted || preset == SoundPreset.MUTE) return

        if (isVibrateEnabled) {
            triggerVibration(preset)
        }

        val job = scope.launch {
            var track: AudioTrack? = null
            try {
                val pcmData = generateSoundPcm(preset) ?: return@launch
                val bufferSize = pcmData.size * 2

                track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSize)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                activeTracks.add(track)

                track.write(pcmData, 0, pcmData.size)
                if (track.state == AudioTrack.STATE_INITIALIZED && !isMuted) {
                    track.play()
                }

                // Wait for sound duration
                val durationMs = (pcmData.size.toFloat() / sampleRate * 1000).toLong() + 30
                kotlinx.coroutines.delay(durationMs)
            } catch (_: Exception) {
                // Ignore transient audio device exceptions
            } finally {
                track?.let { t ->
                    try {
                        activeTracks.remove(t)
                        if (t.state == AudioTrack.STATE_INITIALIZED) {
                            t.stop()
                            t.release()
                        }
                    } catch (_: Exception) {}
                }
            }
        }
        activeJobs.add(job)
        job.invokeOnCompletion { activeJobs.remove(job) }
    }

    /**
     * Instantly ceases all playing audio, stops all AudioTracks and cancels pending jobs.
     * Guaranteed silence when leaving the screen or muting.
     */
    fun stopAll() {
        isMuted = true
        // Cancel all coroutine jobs immediately
        for (job in activeJobs) {
            try { job.cancel() } catch (_: Exception) {}
        }
        activeJobs.clear()

        // Stop and release every audio track
        for (track in activeTracks) {
            try {
                if (track.state == AudioTrack.STATE_INITIALIZED) {
                    track.pause()
                    track.flush()
                    track.stop()
                    track.release()
                }
            } catch (_: Exception) {}
        }
        activeTracks.clear()

        // Reset scope for any future playback
        try { scope.cancel() } catch (_: Exception) {}
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        isMuted = false
    }

    private fun triggerVibration(preset: SoundPreset) {
        try {
            vibrator?.let { v ->
                if (!v.hasVibrator()) return
                val duration = when (preset) {
                    SoundPreset.HEART_THUD, SoundPreset.CINEMA_BOOM -> 35L
                    SoundPreset.KICK_BEAT, SoundPreset.SCI_FI_BLASTER -> 25L
                    SoundPreset.ARCADE_BLIP, SoundPreset.RETRO_COIN -> 18L
                    else -> 10L
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(duration)
                }
            }
        } catch (_: Exception) {}
    }

    /**
     * Generates pure, organic acoustic & digital audio samples at 44.1kHz with smooth
     * sinusoidal attack/decay envelopes so there are never harsh pops, clicks, or glitches.
     */
    private fun generateSoundPcm(preset: SoundPreset): ShortArray? {
        val durationMs = when (preset) {
            SoundPreset.CLOCK_TICK -> 25
            SoundPreset.DIGITAL_BEEP -> 70
            SoundPreset.RADAR_PING -> 160
            SoundPreset.WATER_DROP -> 110
            SoundPreset.ARCADE_BLIP -> 80
            SoundPreset.BELL_DING -> 280
            SoundPreset.HEART_THUD -> 140
            SoundPreset.SCI_FI_BLASTER -> 120
            SoundPreset.RETRO_COIN -> 150
            SoundPreset.CINEMA_BOOM -> 220
            SoundPreset.WOODEN_METRONOME -> 30
            SoundPreset.CYBER_CLICK -> 20
            SoundPreset.COSMIC_CHIME -> 300
            SoundPreset.KICK_BEAT -> 90
            SoundPreset.SYNTH_PLUCK -> 130
            SoundPreset.MUTE -> return null
        }

        val totalSamples = (sampleRate * (durationMs / 1000.0)).toInt().coerceAtLeast(100)
        val buffer = ShortArray(totalSamples)

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            val progress = i.toDouble() / totalSamples

            // Attack ramp (first 5% of samples) prevents clicking
            val attack = if (progress < 0.05) progress / 0.05 else 1.0

            val sample: Double = when (preset) {
                SoundPreset.CLOCK_TICK -> {
                    // Soft, crisp analog watch click (high resonant click with quick damping)
                    val freq = 3200.0 - (progress * 1800.0)
                    val decay = exp(-progress * 28.0)
                    sin(2.0 * PI * freq * t) * decay * 0.75
                }
                SoundPreset.DIGITAL_BEEP -> {
                    // Pleasant watch beep (pure 1760Hz tone with smooth parabolic envelope)
                    val freq = 1760.0
                    val env = (1.0 - progress) * (1.0 - progress)
                    sin(2.0 * PI * freq * t) * env * 0.65
                }
                SoundPreset.RADAR_PING -> {
                    // Gentle sonar ping with smooth decay
                    val freq = 1400.0 - (progress * 600.0)
                    val decay = exp(-progress * 9.0)
                    sin(2.0 * PI * freq * t) * decay * 0.7
                }
                SoundPreset.WATER_DROP -> {
                    // Upward frequency glide simulating a water droplet
                    val freq = 800.0 + (progress * 1100.0)
                    val decay = exp(-progress * 16.0)
                    sin(2.0 * PI * freq * t) * decay * 0.7
                }
                SoundPreset.ARCADE_BLIP -> {
                    // Soft retro chiptune blip (smooth sine 2-tone)
                    val freq = if (progress < 0.5) 880.0 else 1318.5
                    val decay = (1.0 - progress)
                    sin(2.0 * PI * freq * t) * decay * 0.65
                }
                SoundPreset.BELL_DING -> {
                    // Rich metallic bell with acoustic overtone
                    val f1 = sin(2.0 * PI * 1046.5 * t)
                    val f2 = sin(2.0 * PI * 2093.0 * t) * 0.35
                    val decay = exp(-progress * 6.5)
                    (f1 + f2) * decay * 0.65
                }
                SoundPreset.HEART_THUD -> {
                    // Warm low pulse (subtle heartbeat)
                    val freq = 90.0 - (progress * 40.0)
                    val decay = exp(-progress * 14.0)
                    sin(2.0 * PI * freq * t) * decay * 0.85
                }
                SoundPreset.SCI_FI_BLASTER -> {
                    // Futuristic clean frequency sweep
                    val freq = 2200.0 * (1.0 - progress * 0.8)
                    val decay = exp(-progress * 12.0)
                    sin(2.0 * PI * freq * t) * decay * 0.7
                }
                SoundPreset.RETRO_COIN -> {
                    // Clean harmonic coin jump (B5 -> E6)
                    val freq = if (progress < 0.42) 987.77 else 1318.51
                    val decay = exp(-progress * 7.0)
                    sin(2.0 * PI * freq * t) * decay * 0.7
                }
                SoundPreset.CINEMA_BOOM -> {
                    // Deep warm sub-bass impact (without distortion)
                    val freq = 75.0 - (progress * 30.0)
                    val decay = exp(-progress * 6.0)
                    sin(2.0 * PI * freq * t) * decay * 0.85
                }
                SoundPreset.WOODEN_METRONOME -> {
                    // Clean acoustic woodblock tick
                    val freq = 1450.0
                    val decay = exp(-progress * 35.0)
                    sin(2.0 * PI * freq * t) * decay * 0.8
                }
                SoundPreset.CYBER_CLICK -> {
                    // Ultra-short metallic click
                    val freq = 4200.0 - (progress * 2000.0)
                    val decay = exp(-progress * 45.0)
                    sin(2.0 * PI * freq * t) * decay * 0.7
                }
                SoundPreset.COSMIC_CHIME -> {
                    // Celestial major triad: C6, E6, G6
                    val f1 = sin(2.0 * PI * 1046.50 * t)
                    val f2 = sin(2.0 * PI * 1318.51 * t) * 0.45
                    val f3 = sin(2.0 * PI * 1567.98 * t) * 0.3
                    val decay = exp(-progress * 5.0)
                    (f1 + f2 + f3) * decay * 0.55
                }
                SoundPreset.KICK_BEAT -> {
                    // Clean 808 low-frequency punch
                    val freq = 130.0 - (progress * 85.0)
                    val decay = exp(-progress * 14.0)
                    sin(2.0 * PI * freq * t) * decay * 0.85
                }
                SoundPreset.SYNTH_PLUCK -> {
                    // Modern electronic pluck with gentle harmonic
                    val freq = 587.33 // D5
                    val f1 = sin(2.0 * PI * freq * t)
                    val f2 = sin(2.0 * PI * freq * 2.0 * t) * 0.25
                    val decay = exp(-progress * 13.0)
                    (f1 + f2) * decay * 0.7
                }
                SoundPreset.MUTE -> 0.0
            }

            // Apply attack ramp to avoid clicks
            val finalSample = sample * attack
            buffer[i] = (finalSample.coerceIn(-1.0, 1.0) * Short.MAX_VALUE).toInt().toShort()
        }

        return buffer
    }
}
