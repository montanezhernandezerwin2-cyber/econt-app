package com.example.web

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.model.BackgroundPreset
import com.example.data.model.CountdownEntity
import com.example.data.model.FontStylePreset
import com.example.data.model.SoundPreset
import com.example.data.model.VisualEffectType
import java.io.File

object WebCountdownGenerator {

    fun generateHtml(countdown: CountdownEntity): String {
        val targetMillis = countdown.targetTimestamp
        val title = countdown.title.escapeHtml()
        val antetitulo = countdown.antetitulo.escapeHtml()
        val lugar = countdown.lugar.escapeHtml()
        val subtitle = countdown.extraSubtitle.escapeHtml()
        val message = countdown.extraMessage.escapeHtml()
        val quote = countdown.extraQuote.escapeHtml()
        val category = countdown.category.escapeHtml()
        val textColor = countdown.textColorHex
        val effectColor = countdown.effectColorHex
        val imageUrl = countdown.imageUrl.trim()

        val effectType = try {
            VisualEffectType.valueOf(countdown.effectType)
        } catch (_: Exception) {
            VisualEffectType.NEON_PULSE
        }
        val fontPreset = try {
            FontStylePreset.valueOf(countdown.fontStyle)
        } catch (_: Exception) {
            FontStylePreset.DIGITAL
        }
        val soundPreset = try {
            SoundPreset.valueOf(countdown.soundPreset)
        } catch (_: Exception) {
            SoundPreset.CLOCK_TICK
        }

        val fontCss = when (fontPreset) {
            FontStylePreset.DIGITAL -> "'Courier New', monospace, 'Orbitron'"
            FontStylePreset.NEON -> "'Montserrat', 'Segoe UI', sans-serif"
            FontStylePreset.CYBERPUNK -> "'Impact', 'Arial Black', sans-serif"
            FontStylePreset.ELEGANT -> "'Georgia', 'Times New Roman', serif"
            FontStylePreset.ARCADE -> "'Press Start 2P', monospace, fantasy"
            FontStylePreset.HANDWRITTEN -> "'Brush Script MT', 'Segoe Script', cursive"
            FontStylePreset.MONOSPACE -> "'Consolas', 'Courier New', monospace"
            FontStylePreset.BOLD_MINIMAL -> "system-ui, -apple-system, 'Inter', sans-serif"
        }

        val bgStyle = if (imageUrl.isNotBlank()) {
            "background: linear-gradient(rgba(0,0,0,0.65), rgba(0,0,0,0.85)), url('$imageUrl') no-repeat center center fixed; background-size: cover;"
        } else {
            when (try { BackgroundPreset.valueOf(countdown.backgroundPreset) } catch (_: Exception) { BackgroundPreset.COSMIC_SPACE }) {
                BackgroundPreset.COSMIC_SPACE -> "background: radial-gradient(ellipse at bottom, #1B2735 0%, #090A0F 100%);"
                BackgroundPreset.AURORA_NIGHT -> "background: linear-gradient(135deg, #051937, #004d7a, #008793, #00bf72, #a8eb12);"
                BackgroundPreset.CYBER_GRID -> "background: linear-gradient(to bottom, #050510, #150a28);"
                BackgroundPreset.SUNSET_GLOW -> "background: linear-gradient(135deg, #2b1055, #7597de, #d64545, #eaafc8);"
                BackgroundPreset.OCEAN_ABYSS -> "background: linear-gradient(180deg, #021B79 0%, #0575E6 100%);"
                BackgroundPreset.MIDNIGHT_PURPLE -> "background: radial-gradient(circle, #2E0854 0%, #120024 100%);"
                BackgroundPreset.EMERALD_FOREST -> "background: linear-gradient(135deg, #062b16 0%, #02130b 100%);"
                BackgroundPreset.CINEMA_NEON -> "background: radial-gradient(circle at center, #1e0538 0%, #080312 100%);"
                BackgroundPreset.DARK_MINIMAL -> "background: #0d0e12;"
                BackgroundPreset.CUSTOM_IMAGE -> "background: #0A0D14;"
            }
        }

        return """
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
  <title>$title | ChronoGlow</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@700;900&family=Inter:wght@400;600;800&family=Press+Start+2P&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-tap-highlight-color: transparent;
    }
    body {
      $bgStyle
      min-height: 100vh;
      color: #FFFFFF;
      font-family: $fontCss;
      overflow-x: hidden;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      position: relative;
    }
    #effect-canvas {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      pointer-events: none;
      z-index: 1;
    }
    .container {
      position: relative;
      z-index: 2;
      width: 92%;
      max-width: 820px;
      margin: 20px auto;
      padding: 32px 24px;
      background: rgba(15, 23, 42, 0.78);
      backdrop-filter: blur(22px);
      -webkit-backdrop-filter: blur(22px);
      border-radius: 28px;
      border: 1px solid rgba(255, 255, 255, 0.14);
      box-shadow: 0 20px 50px rgba(0, 0, 0, 0.7), 0 0 40px ${effectColor}33;
      text-align: center;
      animation: floatIn 0.8s ease-out;
    }
    @keyframes floatIn {
      from { opacity: 0; transform: translateY(24px) scale(0.97); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    .top-meta {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 10px;
      flex-wrap: wrap;
      margin-bottom: 12px;
    }
    .badge {
      display: inline-block;
      padding: 6px 16px;
      background: ${effectColor}22;
      color: $effectColor;
      border: 1px solid ${effectColor}66;
      border-radius: 20px;
      font-size: 0.8rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 2px;
    }
    .antetitulo {
      font-size: clamp(0.9rem, 2.5vw, 1.25rem);
      font-weight: 700;
      color: $effectColor;
      text-transform: uppercase;
      letter-spacing: 2px;
      margin-bottom: 6px;
    }
    .title {
      font-size: clamp(1.8rem, 5vw, 3.4rem);
      font-weight: 900;
      color: $textColor;
      text-shadow: 0 0 15px ${textColor}88, 0 0 35px ${effectColor}66;
      margin-bottom: 8px;
      line-height: 1.15;
    }
    .lugar {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 6px 16px;
      background: rgba(255, 255, 255, 0.08);
      border-radius: 20px;
      font-size: 0.95rem;
      color: #38BDF8;
      font-weight: 600;
      margin-bottom: 14px;
    }
    .subtitle {
      font-size: clamp(0.95rem, 2.5vw, 1.3rem);
      color: rgba(255, 255, 255, 0.88);
      margin-bottom: 20px;
      font-style: italic;
    }
    .countdown-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 12px;
      margin: 26px 0;
    }
    @media (max-width: 580px) {
      .countdown-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 12px;
      }
    }
    .time-card {
      background: rgba(0, 0, 0, 0.55);
      border-radius: 20px;
      padding: 18px 10px;
      border: 1px solid rgba(255, 255, 255, 0.09);
      box-shadow: inset 0 0 20px rgba(0,0,0,0.6);
      position: relative;
      overflow: hidden;
      transition: transform 0.2s ease, border-color 0.2s ease;
    }
    .time-card:hover {
      border-color: $effectColor;
      transform: translateY(-3px);
    }
    .time-val {
      font-size: clamp(2.2rem, 6vw, 4rem);
      font-weight: 900;
      color: $textColor;
      line-height: 1;
      text-shadow: 0 0 20px ${textColor}99;
    }
    .time-label {
      margin-top: 8px;
      font-size: 0.8rem;
      text-transform: uppercase;
      letter-spacing: 2px;
      color: rgba(255, 255, 255, 0.65);
      font-weight: 600;
    }
    .extra-message {
      margin-top: 18px;
      padding: 16px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 14px;
      font-size: 1.05rem;
      color: #E2E8F0;
      line-height: 1.5;
    }
    .quote {
      margin-top: 12px;
      font-size: 0.95rem;
      color: #94A3B8;
      font-style: italic;
    }
    .controls {
      display: flex;
      justify-content: center;
      gap: 12px;
      margin-top: 24px;
      flex-wrap: wrap;
    }
    .btn {
      padding: 10px 22px;
      border-radius: 30px;
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      color: #fff;
      font-size: 0.9rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
    }
    .btn:hover {
      background: $effectColor;
      color: #000;
      font-weight: 700;
      border-color: $effectColor;
      box-shadow: 0 0 20px ${effectColor}aa;
    }
    .btn-active {
      background: $effectColor;
      color: #000;
      font-weight: 700;
    }
    .target-date {
      margin-top: 20px;
      font-size: 0.85rem;
      color: #64748B;
      letter-spacing: 1px;
    }
  </style>
</head>
<body>

  <canvas id="effect-canvas"></canvas>

  <div class="container">
    <div class="top-meta">
      <div class="badge">$category</div>
    </div>

    ${if (antetitulo.isNotEmpty()) "<div class=\"antetitulo\">$antetitulo</div>" else ""}
    <h1 class="title">$title</h1>
    ${if (lugar.isNotEmpty()) "<div class=\"lugar\">📍 $lugar</div>" else ""}
    ${if (subtitle.isNotEmpty()) "<div class=\"subtitle\">$subtitle</div>" else ""}

    <div class="countdown-grid">
      <div class="time-card">
        <div class="time-val" id="days">00</div>
        <div class="time-label">Días</div>
      </div>
      <div class="time-card">
        <div class="time-val" id="hours">00</div>
        <div class="time-label">Horas</div>
      </div>
      <div class="time-card">
        <div class="time-val" id="minutes">00</div>
        <div class="time-label">Minutos</div>
      </div>
      <div class="time-card">
        <div class="time-val" id="seconds">00</div>
        <div class="time-label">Segundos</div>
      </div>
    </div>

    ${if (message.isNotEmpty()) "<div class=\"extra-message\">$message</div>" else ""}
    ${if (quote.isNotEmpty()) "<div class=\"quote\">“$quote”</div>" else ""}

    <div class="controls">
      <button class="btn" id="soundBtn" onclick="toggleAudio()">🔊 Sonido: Activado</button>
      <button class="btn" onclick="toggleFullScreen()">⛶ Pantalla Completa</button>
    </div>

    <div class="target-date" id="targetDateStr">Destino: ...</div>
  </div>

  <script>
    const targetTimestamp = $targetMillis;
    const effectColor = '$effectColor';
    const soundPreset = '${soundPreset.name}';
    let isSoundOn = ${countdown.isSoundEnabled};

    // Format target date
    const d = new Date(targetTimestamp);
    document.getElementById('targetDateStr').innerText = 'Destino: ' + d.toLocaleString();

    // Web Audio Synthesizer
    let audioCtx = null;
    function playTickSound() {
      if (!isSoundOn || soundPreset === 'MUTE') return;
      try {
        if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        if (audioCtx.state === 'suspended') audioCtx.resume();
        const now = audioCtx.currentTime;
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);

        if (soundPreset === 'DIGITAL_BEEP') {
          osc.frequency.setValueAtTime(1760, now);
          gain.gain.setValueAtTime(0.2, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
          osc.start(now);
          osc.stop(now + 0.08);
        } else if (soundPreset === 'RADAR_PING') {
          osc.frequency.setValueAtTime(1600, now);
          osc.frequency.exponentialRampToValueAtTime(800, now + 0.15);
          gain.gain.setValueAtTime(0.3, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
          osc.start(now);
          osc.stop(now + 0.15);
        } else if (soundPreset === 'ARCADE_BLIP' || soundPreset === 'RETRO_COIN') {
          osc.type = 'square';
          osc.frequency.setValueAtTime(987, now);
          osc.frequency.setValueAtTime(1318, now + 0.04);
          gain.gain.setValueAtTime(0.18, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);
          osc.start(now);
          osc.stop(now + 0.11);
        } else if (soundPreset === 'CINEMA_BOOM' || soundPreset === 'HEART_THUD') {
          osc.type = 'sine';
          osc.frequency.setValueAtTime(75, now);
          osc.frequency.exponentialRampToValueAtTime(35, now + 0.25);
          gain.gain.setValueAtTime(0.4, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
          osc.start(now);
          osc.stop(now + 0.25);
        } else if (soundPreset === 'SCI_FI_BLASTER') {
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(2400, now);
          osc.frequency.exponentialRampToValueAtTime(300, now + 0.1);
          gain.gain.setValueAtTime(0.25, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
          osc.start(now);
          osc.stop(now + 0.1);
        } else {
          // Clock tick / standard click
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(2200, now);
          gain.gain.setValueAtTime(0.25, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.03);
          osc.start(now);
          osc.stop(now + 0.03);
        }
      } catch (e) {}
    }

    function toggleAudio() {
      isSoundOn = !isSoundOn;
      const btn = document.getElementById('soundBtn');
      btn.innerText = isSoundOn ? '🔊 Sonido: Activado' : '🔇 Sonido: Mudo';
      btn.classList.toggle('btn-active', isSoundOn);
      if (isSoundOn) playTickSound();
    }

    function toggleFullScreen() {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(() => {});
      } else {
        if (document.exitFullscreen) document.exitFullscreen();
      }
    }

    // Countdown calculation
    let lastSec = -1;
    function updateCountdown() {
      const now = Date.now();
      const diff = targetTimestamp - now;

      if (diff <= 0) {
        document.getElementById('days').innerText = '00';
        document.getElementById('hours').innerText = '00';
        document.getElementById('minutes').innerText = '00';
        document.getElementById('seconds').innerText = '00';
        return;
      }

      const totalSec = Math.floor(diff / 1000);
      const days = Math.floor(totalSec / 86400);
      const hours = Math.floor((totalSec % 86400) / 3600);
      const minutes = Math.floor((totalSec % 3600) / 60);
      const seconds = totalSec % 60;

      document.getElementById('days').innerText = String(days).padStart(2, '0');
      document.getElementById('hours').innerText = String(hours).padStart(2, '0');
      document.getElementById('minutes').innerText = String(minutes).padStart(2, '0');
      document.getElementById('seconds').innerText = String(seconds).padStart(2, '0');

      if (seconds !== lastSec) {
        lastSec = seconds;
        playTickSound();
      }
    }
    setInterval(updateCountdown, 250);
    updateCountdown();

    // Canvas background particles
    const canvas = document.getElementById('effect-canvas');
    const ctx = canvas.getContext('2d');
    function resize() {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }
    window.addEventListener('resize', resize);
    resize();

    const particles = [];
    for (let i = 0; i < 65; i++) {
      particles.push({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        vx: (Math.random() - 0.5) * 1.5,
        vy: (Math.random() - 0.5) * 1.5,
        radius: Math.random() * 3 + 1,
        alpha: Math.random() * 0.7 + 0.3
      });
    }

    function animate() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const w = canvas.width;
      const h = canvas.height;

      ctx.fillStyle = effectColor;
      for (let p of particles) {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0) p.x = w;
        if (p.x > w) p.x = 0;
        if (p.y < 0) p.y = h;
        if (p.y > h) p.y = 0;

        ctx.globalAlpha = p.alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
      }
      requestAnimationFrame(animate);
    }
    animate();
  </script>
</body>
</html>
        """.trimIndent()
    }

    fun exportToFile(context: Context, countdown: CountdownEntity): File {
        val exportDir = File(context.cacheDir, "web_exports")
        if (!exportDir.exists()) exportDir.mkdirs()
        val sanitizedTitle = countdown.title.replace(Regex("[^a-zA-Z0-9]"), "_").take(20)
        val file = File(exportDir, "cuenta_regresiva_${countdown.id}_$sanitizedTitle.html")
        file.writeText(generateHtml(countdown))
        return file
    }

    fun getShareableUri(context: Context, file: File): Uri {
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    }

    fun openInBrowser(context: Context, countdown: CountdownEntity) {
        val file = exportToFile(context, countdown)
        val uri = getShareableUri(context, file)
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "text/html")
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(android.content.Intent.createChooser(intent, "Abrir con Navegador Web"))
    }

    fun buildShareMessage(countdown: CountdownEntity): String {
        return buildString {
            append("⏱️ Cuenta Regresiva: ${countdown.title}\n")
            if (countdown.antetitulo.isNotBlank()) append("✨ ${countdown.antetitulo}\n")
            if (countdown.lugar.isNotBlank()) append("📍 Lugar: ${countdown.lugar}\n")
            if (countdown.extraSubtitle.isNotBlank()) append("ℹ️ ${countdown.extraSubtitle}\n")
            append("\n🌐 Abre el sitio web interactivo adjunto (.html) en Google Chrome o Safari para ver el conteo con efectos visuales y sonido de segundos en vivo.")
        }
    }

    private fun String.escapeHtml(): String {
        return this.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&#039;")
    }
}
