package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.CalendarNoteEntity
import com.example.data.model.CalendarReminderEntity
import com.example.data.model.CountdownEntity
import com.example.data.model.CustomCategoryEntity

@Database(
    entities = [
        CountdownEntity::class,
        CalendarNoteEntity::class,
        CalendarReminderEntity::class,
        CustomCategoryEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun countdownDao(): CountdownDao
    abstract fun calendarDao(): CalendarDao
    abstract fun categoryDao(): CategoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "chronoglow_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
