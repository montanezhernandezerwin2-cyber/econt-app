package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Visual effects available for the countdown (20 unique, non-repeating, customizable effects).
 */
enum class VisualEffectType(val displayName: String, val description: String) {
    NEON_PULSE("Resplandor Neón Pulsante", "Aura y anillos de energía de neón que pulsan al ritmo del tiempo"),
    SHADOW_FLICKER("Sombras Parpadeantes", "Sombras multicapa oscilantes como fuego o neón crepitante"),
    CYBER_GLITCH("Cyberpunk Glitch", "Distorsión digital con líneas de aberración cromática RGB"),
    CONFETTI_SHOWER("Lluvia de Confeti", "Partículas de celebración cayendo y girando con física"),
    FLOATING_FIREFLIES("Luciérnagas Mágicas", "Luces bioluminiscentes flotando suavemente en la pantalla"),
    COSMIC_STARDUST("Polvo Estelar Cósmico", "Estrellas fugaces viajando a la velocidad de la luz"),
    FLOATING_BUBBLES("Burbujas Iridiscentes", "Burbujas translúcidas flotando hacia arriba con reflejos"),
    MATRIX_RAIN("Lluvia Digital Matrix", "Columnas de caracteres y código digital cayendo en cascada"),
    RETRO_CRT_SCANLINES("Líneas de Escaneo CRT", "Efecto retro monitor arcade con barrido y fósforo"),
    LIQUID_RIPPLE("Ondas Líquidas", "Ondas concéntricas de agua que se expanden hacia el exterior"),
    FIRE_EMBERS("Ascuas y Llamas", "Chispas incandescentes que se elevan con turbulencia de fuego"),
    CHROMA_RAINBOW_SHIFT("Barrido Arcoíris RGB", "Transición cromática espectral que recorre los dígitos"),
    DISCO_STROBE("Destellos Disco Strobe", "Rayos de luces giratorias y destellos estroboscópicos de fiesta"),
    AURORA_BOREALIS("Luces de Aurora Boreal", "Cortinas de luz nórdica ondulando en el horizonte"),
    SNOWFALL_FROST("Copos de Nieve Helada", "Copos de nieve cristalinos flotando suavemente con el viento"),
    ELECTRIC_LIGHTNING("Rayos y Chispas Eléctricas", "Descargas de relámpagos y arcos eléctricos chispeantes"),
    HEARTBEAT_ZOOM("Latido Rítmico de Corazón", "Pulsación de escala enérgica al compás de un latido"),
    GOLDEN_BOKEH("Esferas Doradas Bokeh", "Orbes de luz bokeh de lujo desenfocadas flotando con gracia"),
    HOLOGRAM_SCAN("Escaneo Holográfico", "Láser de barrido vertical con cuadrícula cibernética HUD"),
    POP_ART_DOTS("Puntos Pop Art Dinámicos", "Trama geométrica de cómic estilo Roy Lichtenstein en movimiento")
}

/**
 * Sound styles synthesized on each second tick (15 distinct sounds + mute).
 */
enum class SoundPreset(val displayName: String) {
    CLOCK_TICK("Tic-Tac Mecánico"),
    DIGITAL_BEEP("Bip Digital 8-Bit"),
    RADAR_PING("Sonar Radar Futurista"),
    WATER_DROP("Gota de Agua Cristalina"),
    ARCADE_BLIP("Blip Arcade Clásico"),
    BELL_DING("Campanilla Suave"),
    HEART_THUD("Latido de Pulso"),
    SCI_FI_BLASTER("Láser Espacial Blaster"),
    RETRO_COIN("Moneda Retro Arcade"),
    CINEMA_BOOM("Impacto Cine Subwoofer"),
    WOODEN_METRONOME("Metrónomo de Madera"),
    CYBER_CLICK("Click Cibernético"),
    COSMIC_CHIME("Campana Cósmica"),
    KICK_BEAT("Bombo Electrónico"),
    SYNTH_PLUCK("Pluck Melódico"),
    MUTE("Silencio / Desactivado")
}

/**
 * Font styles for the countdown display.
 */
enum class FontStylePreset(val displayName: String) {
    DIGITAL("Digital 7-Segmentos"),
    NEON("Neón Moderno"),
    CYBERPUNK("Futurista Cyber"),
    ELEGANT("Serif Elegante"),
    ARCADE("Retro Arcade"),
    HANDWRITTEN("Caligrafía Cursiva"),
    MONOSPACE("Código Monospace"),
    BOLD_MINIMAL("Minimalista Grueso")
}

/**
 * Background style presets.
 */
enum class BackgroundPreset(val displayName: String) {
    COSMIC_SPACE("Espacio Cósmico"),
    AURORA_NIGHT("Noche Aurora"),
    CYBER_GRID("Malla Cyberpunk"),
    SUNSET_GLOW("Atardecer Dorado"),
    OCEAN_ABYSS("Abismo Marino"),
    MIDNIGHT_PURPLE("Púrpura Medianoche"),
    EMERALD_FOREST("Bosque Esmeralda"),
    DARK_MINIMAL("Negro Minimalista"),
    CINEMA_NEON("Cine & Película Neón"),
    CUSTOM_IMAGE("Foto Personalizada / Enlace")
}

@Entity(tableName = "countdowns")
data class CountdownEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val targetTimestamp: Long, // Epoch millis
    val category: String = "Película / Cine",
    val fontStyle: String = FontStylePreset.DIGITAL.name,
    val textColorHex: String = "#00FFFF", // Default cyan
    val effectType: String = VisualEffectType.NEON_PULSE.name,
    val effectColorHex: String = "#00FF66", // Default emerald green
    val effectSpeed: Float = 1.0f, // 0.5f to 2.5f
    val effectIntensity: Float = 1.0f, // 0.2f to 2.0f
    val backgroundPreset: String = BackgroundPreset.COSMIC_SPACE.name,
    val customImageUri: String? = null,
    val imageUrl: String = "", // Direct Web Image Link / Enlace de Internet
    val soundPreset: String = SoundPreset.CLOCK_TICK.name,
    val isSoundEnabled: Boolean = true,
    val isVibrateEnabled: Boolean = true,
    val antetitulo: String = "", // Antetítulo (ej: Estreno Exclusivo, Gran Función)
    val lugar: String = "", // Lugar / Ubicación (ej: Cinépolis Sala IMAX, Auditorio)
    val extraSubtitle: String = "", // Subtítulo / Descripción
    val extraMessage: String = "", // Mensaje / Notas adicionales
    val extraQuote: String = "", // Frase / Cita
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "calendar_notes")
data class CalendarNoteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dateString: String, // "YYYY-MM-DD"
    val title: String,
    val content: String,
    val colorHex: String = "#3B82F6",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "calendar_reminders")
data class CalendarReminderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dateString: String, // "YYYY-MM-DD"
    val timeString: String = "12:00",
    val title: String,
    val isCompleted: Boolean = false,
    val priority: String = "Normal" // "Baja", "Normal", "Alta"
)

@Entity(tableName = "custom_categories")
data class CustomCategoryEntity(
    @PrimaryKey
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)
