package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.CalendarNoteEntity
import com.example.data.model.CalendarReminderEntity
import com.example.data.model.CountdownEntity
import com.example.data.model.CustomCategoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CountdownDao {
    @Query("SELECT * FROM countdowns ORDER BY targetTimestamp ASC")
    fun getAllCountdowns(): Flow<List<CountdownEntity>>

    @Query("SELECT * FROM countdowns WHERE id = :id LIMIT 1")
    suspend fun getCountdownById(id: Long): CountdownEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCountdown(countdown: CountdownEntity): Long

    @Update
    suspend fun updateCountdown(countdown: CountdownEntity)

    @Delete
    suspend fun deleteCountdown(countdown: CountdownEntity)

    @Query("DELETE FROM countdowns WHERE id = :id")
    suspend fun deleteCountdownById(id: Long)
}

@Dao
interface CalendarDao {
    @Query("SELECT * FROM calendar_notes WHERE dateString = :date ORDER BY updatedAt DESC")
    fun getNotesForDate(date: String): Flow<List<CalendarNoteEntity>>

    @Query("SELECT * FROM calendar_notes ORDER BY updatedAt DESC")
    fun getAllNotes(): Flow<List<CalendarNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: CalendarNoteEntity): Long

    @Update
    suspend fun updateNote(note: CalendarNoteEntity)

    @Delete
    suspend fun deleteNote(note: CalendarNoteEntity)

    @Query("SELECT * FROM calendar_reminders WHERE dateString = :date ORDER BY timeString ASC")
    fun getRemindersForDate(date: String): Flow<List<CalendarReminderEntity>>

    @Query("SELECT * FROM calendar_reminders ORDER BY dateString ASC, timeString ASC")
    fun getAllReminders(): Flow<List<CalendarReminderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: CalendarReminderEntity): Long

    @Update
    suspend fun updateReminder(reminder: CalendarReminderEntity)

    @Delete
    suspend fun deleteReminder(reminder: CalendarReminderEntity)
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM custom_categories ORDER BY createdAt ASC")
    fun getAllCategories(): Flow<List<CustomCategoryEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCategory(category: CustomCategoryEntity)

    @Delete
    suspend fun deleteCategory(category: CustomCategoryEntity)
}
