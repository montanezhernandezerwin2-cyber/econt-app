package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.AppScreen
import com.example.ui.MainViewModel
import com.example.ui.screens.CalendarHomeScreen
import com.example.ui.screens.CountdownStudioScreen
import com.example.ui.screens.CountdownViewerScreen
import com.example.ui.theme.ChronoGlowTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val currentPalette by viewModel.currentPalette.collectAsState()
            val currentScreen by viewModel.currentScreen.collectAsState()
            val countdowns by viewModel.countdowns.collectAsState()
            val notes by viewModel.notes.collectAsState()
            val reminders by viewModel.reminders.collectAsState()
            val customCategories by viewModel.customCategories.collectAsState()

            ChronoGlowTheme(selectedPalette = currentPalette) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Crossfade(targetState = currentScreen, label = "screen_crossfade") { screen ->
                        when (screen) {
                            is AppScreen.Splash -> {
                                com.example.ui.screens.EcontSplashScreen(
                                    onFinished = {
                                        viewModel.navigateTo(AppScreen.CalendarHome)
                                    }
                                )
                            }

                            is AppScreen.CalendarHome -> {
                                CalendarHomeScreen(
                                    countdowns = countdowns,
                                    notes = notes,
                                    reminders = reminders,
                                    currentPalette = currentPalette,
                                    onPaletteChanged = { viewModel.setPalette(it) },
                                    onCreateCountdown = { initialDate ->
                                        viewModel.navigateTo(AppScreen.Studio(initialDateString = initialDate))
                                    },
                                    onViewCountdown = { countdown ->
                                        viewModel.navigateTo(AppScreen.Viewer(countdown))
                                    },
                                    onDeleteCountdown = { countdown ->
                                        viewModel.deleteCountdown(countdown)
                                    },
                                    onSaveNote = { note ->
                                        viewModel.saveNote(note)
                                    },
                                    onDeleteNote = { note ->
                                        viewModel.deleteNote(note)
                                    },
                                    onSaveReminder = { reminder ->
                                        viewModel.saveReminder(reminder)
                                    },
                                    onToggleReminder = { reminder ->
                                        viewModel.toggleReminder(reminder)
                                    },
                                    onDeleteReminder = { reminder ->
                                        viewModel.deleteReminder(reminder)
                                    }
                                )
                            }

                            is AppScreen.Studio -> {
                                val editing = screen.countdownToEdit
                                BackHandler {
                                    if (editing != null) {
                                        viewModel.navigateTo(AppScreen.Viewer(editing))
                                    } else {
                                        viewModel.navigateTo(AppScreen.CalendarHome)
                                    }
                                }
                                CountdownStudioScreen(
                                    initialCountdown = editing,
                                    initialDateString = screen.initialDateString,
                                    availableCategories = customCategories,
                                    onAddCustomCategory = { viewModel.addCategory(it) },
                                    onSave = { countdown ->
                                        viewModel.saveCountdown(countdown, stayInViewer = true)
                                    },
                                    onBack = {
                                        if (editing != null) {
                                            viewModel.navigateTo(AppScreen.Viewer(editing))
                                        } else {
                                            viewModel.navigateTo(AppScreen.CalendarHome)
                                        }
                                    }
                                )
                            }

                            is AppScreen.Viewer -> {
                                BackHandler {
                                    viewModel.navigateTo(AppScreen.CalendarHome)
                                }
                                CountdownViewerScreen(
                                    countdown = screen.countdown,
                                    onEdit = {
                                        viewModel.navigateTo(AppScreen.Studio(countdownToEdit = screen.countdown))
                                    },
                                    onBack = {
                                        viewModel.navigateTo(AppScreen.CalendarHome)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
